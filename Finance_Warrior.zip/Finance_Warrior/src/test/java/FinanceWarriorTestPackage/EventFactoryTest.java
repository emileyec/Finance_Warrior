/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package FinanceWarriorTestPackage;

import Events.Achievement;
import Events.AchievementCreator;
import Events.Event;
import Events.EventCreator;
import Events.MiniEvent;
import Events.MiniEventCreator;
import Events.Quest;
import Events.QuestCreator;
import Levels.Level;
import Levels.Vault;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.Calendar;

/**
 * Unit tests for Event Factory Pattern
 * @author jemim
 */

@DisplayName("Event Factory Tests")
public class EventFactoryTest {
    
    private Level level;
    private Vault vault;
    private Date creationDate;
    private Date dueDate;
    
    @BeforeEach
    void setUp() {
        level = new Level();
        level.setXpNeeded(1000);
        vault = new Vault();
        vault.updateCoins(500);
        
        creationDate = new Date();
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 7);
        dueDate = cal.getTime();
    }
    
    @Test
    @DisplayName("QuestCreator should create Quest objects")
    void testQuestCreator() {
        EventCreator creator = new QuestCreator(
            "Q001", 
            "Save $500", 
            creationDate, 
            dueDate, 
            3, 
            level, 
            vault
        );
        
        Event event = creator.createEvent();
        
        assertNotNull(event);
        assertTrue(event instanceof Quest);
        assertEquals("Quest", event.getType());
    }
    
    @Test
    @DisplayName("QuestCreator should create Quest with correct properties")
    void testQuestCreatorProperties() {
        EventCreator creator = new QuestCreator(
            "Q002", 
            "Exercise daily", 
            creationDate, 
            dueDate, 
            5, 
            level, 
            vault
        );
        
        Event event = creator.createEvent();
        Quest quest = (Quest) event;
        
        assertEquals("Q002", quest.getQuestId());
        assertEquals("Exercise daily", quest.getGoal());
        assertEquals(5, quest.getPriorityLvl());
        assertEquals("Not Started", quest.getStatus());
    }
    
    @Test
    @DisplayName("AchievementCreator should create Achievement objects")
    void testAchievementCreator() {
        EventCreator creator = new AchievementCreator(
            "A001",                      // achievementId
            "First Quest Complete",      // title
            "Complete your first quest", // details
            5,                           // xp
            25,                          // coins
            level, 
            vault
        );
        
        Event event = creator.createEvent();
        
        assertNotNull(event);
        assertTrue(event instanceof Achievement);
        assertEquals("Achievement", event.getType());
    }
    
    @Test
    @DisplayName("MiniEventCreator should create MiniEvent objects")
    void testMiniEventCreator() {
        EventCreator creator = new MiniEventCreator(
            "M001",                      // eventId
            "Daily Login Bonus",         // title
            "Welcome back warrior!",     // quote
            2,                           // xp
            10,                          // coins
            dueDate,                     // expiration
            level, 
            vault
        );
        
        Event event = creator.createEvent();
        
        assertNotNull(event);
        assertTrue(event instanceof MiniEvent);
        assertEquals("MiniEvent", event.getType());
    }
    
    @Test
    @DisplayName("Multiple factories should create independent events")
    void testMultipleFactories() {
        EventCreator questCreator = new QuestCreator(
            "Q001", "Goal 1", creationDate, dueDate, 3, level, vault
        );
        EventCreator achievementCreator = new AchievementCreator(
            "A001",                      // achievementId
            "Achievement 1",             // title
            "First achievement",         // details
            5,                           // xp
            25,                          // coins
            level, 
            vault
        );
        
        Event quest = questCreator.createEvent();
        Event achievement = achievementCreator.createEvent();
        
        assertNotEquals(quest.getType(), achievement.getType());
        assertEquals("Quest", quest.getType());
        assertEquals("Achievement", achievement.getType());
    }
    
    @Test
    @DisplayName("Factory should create events with different parameters")
    void testFactoryWithDifferentParameters() {
        EventCreator creator1 = new QuestCreator(
            "Q001", "Goal 1", creationDate, dueDate, 1, level, vault
        );
        EventCreator creator2 = new QuestCreator(
            "Q002", "Goal 2", creationDate, dueDate, 5, level, vault
        );
        
        Quest quest1 = (Quest) creator1.createEvent();
        Quest quest2 = (Quest) creator2.createEvent();
        
        assertNotEquals(quest1.getQuestId(), quest2.getQuestId());
        assertNotEquals(quest1.getPriorityLvl(), quest2.getPriorityLvl());
    }
    
    @Test
    @DisplayName("Created events should be functional")
    void testCreatedEventFunctionality() {
        EventCreator creator = new QuestCreator(
            "Q001", "Test Quest", creationDate, dueDate, 3, level, vault
        );
        
        Event event = creator.createEvent();
        
        int initialXP = level.getXpEarned();
        int initialCoins = vault.getCoins();
        
        event.complete();
        
        assertTrue(level.getXpEarned() > initialXP);
        assertTrue(vault.getCoins() > initialCoins);
    }
    
    @Test
    @DisplayName("Achievement should award appropriate rewards")
    void testAchievementRewards() {
        EventCreator creator = new AchievementCreator(
            "A001",                          // achievementId
            "First Achievement",             // title
            "Your first achievement",        // details
            5,                               // xp reward
            25,                              // coins reward
            level, 
            vault
        );
        
        Event achievement = creator.createEvent();
        
        int initialXP = level.getXpEarned();
        int initialCoins = vault.getCoins();
        
        achievement.addXP();
        achievement.addCoins();
        
        assertTrue(level.getXpEarned() >= initialXP);
        assertTrue(vault.getCoins() >= initialCoins);
    }
    
    @Test
    @DisplayName("MiniEvent should have appropriate rewards")
    void testMiniEventRewards() {
        EventCreator creator = new MiniEventCreator(
            "M001",                      // eventId
            "Daily Bonus",               // title
            "Keep up the good work!",    // quote
            2,                           // xp reward
            10,                          // coins reward
            dueDate,                     // expiration
            level, 
            vault
        );
        
        Event miniEvent = creator.createEvent();
        
        int initialXP = level.getXpEarned();
        int initialCoins = vault.getCoins();
        
        miniEvent.addXP();
        miniEvent.addCoins();
        
        assertTrue(level.getXpEarned() >= initialXP);
        assertTrue(vault.getCoins() >= initialCoins);
    }
    
    @Test
    @DisplayName("ViewDetails should work for all event types")
    void testViewDetailsAllEventTypes() {
        EventCreator questCreator = new QuestCreator(
            "Q001", "Quest Goal", creationDate, dueDate, 3, level, vault
        );
        EventCreator achievementCreator = new AchievementCreator(
            "A001",                          // achievementId
            "Achievement Name",              // title
            "Achievement Description",       // details
            5,                               // xp
            25,                              // coins
            level, 
            vault
        );
        EventCreator miniEventCreator = new MiniEventCreator(
            "M001",                      // eventId
            "Mini Task",                 // title
            "You can do it!",            // quote
            2,                           // xp
            10,                          // coins
            dueDate,                     // expiration
            level, 
            vault
        );
        
        Event quest = questCreator.createEvent();
        Event achievement = achievementCreator.createEvent();
        Event miniEvent = miniEventCreator.createEvent();
        
        assertNotNull(quest.viewDetails());
        assertNotNull(achievement.viewDetails());
        assertNotNull(miniEvent.viewDetails());
        
        assertTrue(quest.viewDetails().contains("Quest"));
        assertTrue(achievement.viewDetails().contains("Achievement"));
        assertTrue(miniEvent.viewDetails().contains("MiniEvent"));
    }
    
    @Test
    @DisplayName("Factory pattern should support polymorphism")
    void testFactoryPolymorphism() {
        EventCreator[] creators = {
            new QuestCreator("Q001", "Quest", creationDate, dueDate, 3, level, vault),
            new AchievementCreator("A001", "Achievement", "Description", 5, 25, level, vault),
            new MiniEventCreator("M001", "MiniEvent", "Quote", 2, 10, dueDate, level, vault)
        };
        
        for (EventCreator creator : creators) {
            Event event = creator.createEvent();
            assertNotNull(event);
            assertNotNull(event.getType());
        }
    }
}