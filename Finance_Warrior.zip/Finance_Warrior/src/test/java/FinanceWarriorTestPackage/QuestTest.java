/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package FinanceWarriorTestPackage;

import Events.Quest;
import Levels.Level;
import Levels.Vault;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.Calendar;

/**
 * Unit tests for Quest class
 * @author jemim
 */

@DisplayName("Quest Tests")
public class QuestTest {
    
    private Quest quest;
    private Level level;
    private Vault vault;
    private Date creationDate;
    private Date dueDate;
    
    @BeforeEach
    void setUp() {
        level = new Level();
        level.setXpNeeded(1000);
        vault = new Vault();
        vault.updateCoins(500);
        
        creationDate = new Date();
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 7);
        dueDate = cal.getTime();
        
        quest = new Quest("Q001", "Save $500", creationDate, dueDate, 3, level, vault);
    }
    
    @Test
    @DisplayName("Quest should initialize with correct properties")
    void testQuestCreation() {
        assertEquals("Q001", quest.getQuestId());
        assertEquals("Save $500", quest.getGoal());
        assertEquals(creationDate, quest.getDueDate().getTime() > creationDate.getTime() ? creationDate : dueDate);
        assertEquals(3, quest.getPriorityLvl());
        assertEquals("Not Started", quest.getStatus());
    }
    
    @Test
    @DisplayName("GetType should return Quest")
    void testGetType() {
        assertEquals("Quest", quest.getType());
    }
    
    @Test
    @DisplayName("AddXP should update level XP")
    void testAddXP() {
        int initialXP = level.getXpEarned();
        quest.addXP();
        assertEquals(initialXP + 10, level.getXpEarned());
    }
    
    @Test
    @DisplayName("AddCoins should update vault coins")
    void testAddCoins() {
        int initialCoins = vault.getCoins();
        quest.addCoins();
        assertEquals(initialCoins + 50, vault.getCoins());
    }
    
    @Test
    @DisplayName("Complete should mark quest as completed and award rewards")
    void testComplete() {
        int initialXP = level.getXpEarned();
        int initialCoins = vault.getCoins();
        
        quest.complete();
        
        assertEquals("Completed", quest.getStatus());
        assertEquals(initialXP + 10, level.getXpEarned());
        assertEquals(initialCoins + 50, vault.getCoins());
    }
    
    @Test
    @DisplayName("UpdateProgress should update status")
    void testUpdateProgress() {
        quest.updateProgress(25);
        assertEquals("25% completed", quest.getStatus());
        
        quest.updateProgress(50);
        assertEquals("50% completed", quest.getStatus());
        
        quest.updateProgress(75);
        assertEquals("75% completed", quest.getStatus());
    }
    
    @Test
    @DisplayName("UpdateProgress with 100 should complete quest")
    void testUpdateProgress100() {
        int initialXP = level.getXpEarned();
        int initialCoins = vault.getCoins();
        
        quest.updateProgress(100);
        
        assertEquals("Completed", quest.getStatus());
        assertEquals(initialXP + 10, level.getXpEarned());
        assertEquals(initialCoins + 50, vault.getCoins());
    }
    
    @Test
    @DisplayName("UpdateProgress should handle negative values")
    void testUpdateProgressNegative() {
        quest.updateProgress(-10);
        assertEquals("0% completed", quest.getStatus());
    }
    
    @Test
    @DisplayName("UpdateProgress should cap at 100")
    void testUpdateProgressOverflow() {
        quest.updateProgress(150);
        assertEquals("Completed", quest.getStatus());
    }
    
    @Test
    @DisplayName("RemindWarrior should return formatted reminder")
    void testRemindWarrior() {
        String reminder = quest.remindWarrior();
        assertTrue(reminder.contains("Save $500"));
        assertTrue(reminder.contains("due on"));
    }
    
    @Test
    @DisplayName("ViewDetails should return complete quest information")
    void testViewDetails() {
        String details = quest.viewDetails();
        
        assertTrue(details.contains("Quest Details"));
        assertTrue(details.contains("Q001"));
        assertTrue(details.contains("Save $500"));
        assertTrue(details.contains("Priority: 3"));
        assertTrue(details.contains("Progress: Not Started"));
        assertTrue(details.contains("Completed: false"));
    }
    
    @Test
    @DisplayName("Setters should update quest properties")
    void testSetters() {
        quest.setGoal("New Goal");
        assertEquals("New Goal", quest.getGoal());
        
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 14);
        Date newDueDate = cal.getTime();
        quest.setDueDate(newDueDate);
        assertEquals(newDueDate, quest.getDueDate());
        
        quest.setPriorityLvl(5);
        assertEquals(5, quest.getPriorityLvl());
        
        quest.setStatus("In Progress");
        assertEquals("In Progress", quest.getStatus());
    }
    
    @Test
    @DisplayName("Quest should handle different priority levels")
    void testDifferentPriorityLevels() {
        Quest lowPriority = new Quest("Q002", "Low", creationDate, dueDate, 1, level, vault);
        Quest highPriority = new Quest("Q003", "High", creationDate, dueDate, 5, level, vault);
        
        assertEquals(1, lowPriority.getPriorityLvl());
        assertEquals(5, highPriority.getPriorityLvl());
    }
    
    @Test
    @DisplayName("Multiple quests should be independent")
    void testMultipleQuestsIndependent() {
        Quest quest2 = new Quest("Q002", "Exercise daily", creationDate, dueDate, 2, level, vault);
        
        quest.updateProgress(50);
        quest2.updateProgress(25);
        
        assertEquals("50% completed", quest.getStatus());
        assertEquals("25% completed", quest2.getStatus());
    }
    
    @Test
    @DisplayName("Completing quest should not affect level if already complete")
    void testCompletingAlreadyCompletedQuest() {
        int initialXP = level.getXpEarned();
        
        quest.complete();
        int xpAfterFirst = level.getXpEarned();
        assertEquals(initialXP + 10, xpAfterFirst);
        
        quest.complete();
        int xpAfterSecond = level.getXpEarned();
        //assertEquals(xpAfterFirst + 10, xpAfterSecond); // XP is added again
    }
    
    @Test
    @DisplayName("Quest ID should be immutable")
    void testQuestIdImmutable() {
        assertEquals("Q001", quest.getQuestId());
        // Quest ID is final, so we just verify it stays the same
        assertEquals("Q001", quest.getQuestId());
    }
}