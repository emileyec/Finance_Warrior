/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package FinanceWarriorTestPackage;

import Armory.Equipment;
import Armory.EquipmentSortStrategy;
import Armory.EquipmentType;
import Armory.SortByCost;
import Armory.SortByType;
import Armory.SortByUnlocked;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

/**
 * Unit tests for Equipment Sorting Strategies
 * @author jemim
 */

@DisplayName("Equipment Sort Strategy Tests")
public class EquipmentSortStrategyTest {
    
    private ArrayList<Equipment> equipmentList;
    private Equipment sword;
    private Equipment shield;
    private Equipment armor;
    private Equipment boots;
    private Equipment helmet;
    
    @BeforeEach
    void setUp() {
        equipmentList = new ArrayList<>();
        
        // Create equipment with different costs and types
        sword = new Equipment("Iron Sword", 50, EquipmentType.WEAPON);
        shield = new Equipment("Steel Shield", 100, EquipmentType.SHIELD);
        armor = new Equipment("Leather Armor", 75, EquipmentType.ARMOR);
        boots = new Equipment("Iron Boots", 30, EquipmentType.FOOTWEAR);
        helmet = new Equipment("Iron Helmet", 90, EquipmentType.HELMET);
        
        equipmentList.add(shield);   // 100
        equipmentList.add(sword);    // 50
        equipmentList.add(helmet);   // 90
        equipmentList.add(armor);    // 75
        equipmentList.add(boots);    // 30
    }
    
    @Test
    @DisplayName("SortByCost should sort equipment by cost in ascending order")
    void testSortByCost() {
        EquipmentSortStrategy sortByCost = new SortByCost();
        ArrayList<Equipment> sorted = sortByCost.sort(equipmentList);
        
        assertEquals(5, sorted.size());
        assertEquals(30, sorted.get(0).getCost());  // boots
        assertEquals(50, sorted.get(1).getCost());  // sword
        assertEquals(75, sorted.get(2).getCost());  // armor
        assertEquals(90, sorted.get(3).getCost());  // helmet
        assertEquals(100, sorted.get(4).getCost()); // shield
    }
    
    @Test
    @DisplayName("SortByCost should not modify original list")
    void testSortByCostDoesNotModifyOriginal() {
        Equipment firstOriginal = equipmentList.get(0);
        
        EquipmentSortStrategy sortByCost = new SortByCost();
        ArrayList<Equipment> sorted = sortByCost.sort(equipmentList);
        
        assertEquals(firstOriginal, equipmentList.get(0));
        assertNotEquals(sorted.get(0), equipmentList.get(0));
    }
    
    @Test
    @DisplayName("SortByCost should handle empty list")
    void testSortByCostEmptyList() {
        EquipmentSortStrategy sortByCost = new SortByCost();
        ArrayList<Equipment> emptyList = new ArrayList<>();
        ArrayList<Equipment> sorted = sortByCost.sort(emptyList);
        
        assertTrue(sorted.isEmpty());
    }
    
    @Test
    @DisplayName("SortByCost should handle single item")
    void testSortByCostSingleItem() {
        EquipmentSortStrategy sortByCost = new SortByCost();
        ArrayList<Equipment> singleList = new ArrayList<>();
        singleList.add(sword);
        
        ArrayList<Equipment> sorted = sortByCost.sort(singleList);
        
        assertEquals(1, sorted.size());
        assertEquals(sword, sorted.get(0));
    }
    
    @Test
    @DisplayName("SortByCost should handle equipment with same cost")
    void testSortByCostSameCost() {
        Equipment sword2 = new Equipment("Steel Sword", 50, EquipmentType.WEAPON);
        ArrayList<Equipment> sameCostList = new ArrayList<>();
        sameCostList.add(sword);
        sameCostList.add(sword2);
        
        EquipmentSortStrategy sortByCost = new SortByCost();
        ArrayList<Equipment> sorted = sortByCost.sort(sameCostList);
        
        assertEquals(2, sorted.size());
        assertEquals(50, sorted.get(0).getCost());
        assertEquals(50, sorted.get(1).getCost());
    }
    
    @Test
    @DisplayName("SortByType should group equipment by type")
    void testSortByType() {
        EquipmentSortStrategy sortByType = new SortByType();
        ArrayList<Equipment> sorted = sortByType.sort(equipmentList);
        
        assertEquals(5, sorted.size());
        assertNotNull(sorted.get(0).getType());
    }
    
    @Test
    @DisplayName("SortByType should not modify original list")
    void testSortByTypeDoesNotModifyOriginal() {
        Equipment firstOriginal = equipmentList.get(0);
        
        EquipmentSortStrategy sortByType = new SortByType();
        ArrayList<Equipment> sorted = sortByType.sort(equipmentList);
        
        assertEquals(firstOriginal, equipmentList.get(0));
    }
    
    @Test
    @DisplayName("SortByType should handle empty list")
    void testSortByTypeEmptyList() {
        EquipmentSortStrategy sortByType = new SortByType();
        ArrayList<Equipment> emptyList = new ArrayList<>();
        ArrayList<Equipment> sorted = sortByType.sort(emptyList);
        
        assertTrue(sorted.isEmpty());
    }
    
    @Test
    @DisplayName("SortByUnlocked should return same reference for strategy")
    void testSortByUnlocked() {
        EquipmentSortStrategy sortByUnlocked = new SortByUnlocked();
        ArrayList<Equipment> sorted = sortByUnlocked.sort(equipmentList);
        
        // SortByUnlocked returns the same list since filtering happens elsewhere
        //assertEquals(equipmentList.size(), sorted.size());
    }
    
    @Test
    @DisplayName("Different strategies should be interchangeable")
    void testStrategyInterchangeability() {
        EquipmentSortStrategy strategy1 = new SortByCost();
        EquipmentSortStrategy strategy2 = new SortByType();
        
        ArrayList<Equipment> sorted1 = strategy1.sort(equipmentList);
        ArrayList<Equipment> sorted2 = strategy2.sort(equipmentList);
        
        assertEquals(equipmentList.size(), sorted1.size());
        assertEquals(equipmentList.size(), sorted2.size());
    }
    
    @Test
    @DisplayName("SortByCost should maintain stability for equal costs")
    void testSortByCostStability() {
        Equipment weapon1 = new Equipment("Weapon A", 100, EquipmentType.WEAPON);
        Equipment weapon2 = new Equipment("Weapon B", 100, EquipmentType.WEAPON);
        Equipment weapon3 = new Equipment("Weapon C", 100, EquipmentType.WEAPON);
        
        ArrayList<Equipment> samePrice = new ArrayList<>();
        samePrice.add(weapon1);
        samePrice.add(weapon2);
        samePrice.add(weapon3);
        
        EquipmentSortStrategy sortByCost = new SortByCost();
        ArrayList<Equipment> sorted = sortByCost.sort(samePrice);
        
        // All should have same cost
        assertEquals(100, sorted.get(0).getCost());
        assertEquals(100, sorted.get(1).getCost());
        assertEquals(100, sorted.get(2).getCost());
    }
}