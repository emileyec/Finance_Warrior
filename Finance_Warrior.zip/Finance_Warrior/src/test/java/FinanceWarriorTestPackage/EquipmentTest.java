/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package FinanceWarriorTestPackage;

import Armory.Equipment;
import Armory.EquipmentType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Equipment class
 * @author jemim
 */

@DisplayName("Equipment Tests")
public class EquipmentTest {
    
    private Equipment weapon;
    private Equipment shield;
    private Equipment armor;
    
    @BeforeEach
    void setUp() {
        weapon = new Equipment("Iron Sword", 50, EquipmentType.WEAPON);
        shield = new Equipment("Steel Shield", 100, EquipmentType.SHIELD);
        armor = new Equipment("Leather Armor", 75, EquipmentType.ARMOR);
    }
    
    @Test
    @DisplayName("Equipment should be created with correct properties")
    void testEquipmentCreation() {
        assertEquals("Iron Sword", weapon.getName());
        assertEquals(50, weapon.getCost());
        assertEquals(EquipmentType.WEAPON, weapon.getType());
        assertFalse(weapon.getStatus(), "New equipment should be locked");
    }
    
    @Test
    @DisplayName("Equipment should unlock when unlockEquipment is called")
    void testUnlockEquipment() {
        assertFalse(weapon.getStatus(), "Equipment should start locked");
        weapon.unlockEquipment();
        assertTrue(weapon.getStatus(), "Equipment should be unlocked after unlocking");
    }
    
    @Test
    @DisplayName("Equipment toString should return formatted string")
    void testToString() {
        String expected = "Iron Sword (50)";
        assertEquals(expected, weapon.toString());
    }
    
    @Test
    @DisplayName("Multiple unlocks should keep equipment unlocked")
    void testMultipleUnlocks() {
        weapon.unlockEquipment();
        assertTrue(weapon.getStatus());
        weapon.unlockEquipment(); // Call again
        assertTrue(weapon.getStatus(), "Equipment should remain unlocked");
    }
    
    @Test
    @DisplayName("Different equipment types should have correct types")
    void testEquipmentTypes() {
        assertEquals(EquipmentType.WEAPON, weapon.getType());
        assertEquals(EquipmentType.SHIELD, shield.getType());
        assertEquals(EquipmentType.ARMOR, armor.getType());
    }
    
    @Test
    @DisplayName("Equipment with zero cost should be valid")
    void testZeroCostEquipment() {
        Equipment freeItem = new Equipment("Starter Weapon", 0, EquipmentType.WEAPON);
        assertEquals(0, freeItem.getCost());
        assertNotNull(freeItem);
    }
    
    @Test
    @DisplayName("Equipment should handle all equipment types")
    void testAllEquipmentTypes() {
        Equipment helmet = new Equipment("Iron Helmet", 70, EquipmentType.HELMET);
        Equipment boots = new Equipment("Leather Boots", 30, EquipmentType.FOOTWEAR);
        Equipment gauntlet = new Equipment("Steel Gauntlets", 90, EquipmentType.GAUNTLET);
        Equipment accessory = new Equipment("Magic Ring", 200, EquipmentType.ACCESSORY);
        Equipment torso = new Equipment("Torso Plate", 150, EquipmentType.TORSO);
        
        assertEquals(EquipmentType.HELMET, helmet.getType());
        assertEquals(EquipmentType.FOOTWEAR, boots.getType());
        assertEquals(EquipmentType.GAUNTLET, gauntlet.getType());
        assertEquals(EquipmentType.ACCESSORY, accessory.getType());
        assertEquals(EquipmentType.TORSO, torso.getType());
    }
}
