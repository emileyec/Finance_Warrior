/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package FinanceWarriorTestPackage;

import Levels.Vault;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Vault class
 * @author jemim
 */

@DisplayName("Vault Tests")
public class VaultTest {
    
    private Vault vault;
    
    @BeforeEach
    void setUp() {
        vault = new Vault();
    }
    
    @Test
    @DisplayName("New vault should have zero values")
    void testDefaultConstructor() {
        assertEquals(0, vault.getCoins());
        assertEquals(0, vault.getTotalSaved());
        assertEquals(0, vault.getQuestsCompleted());
        assertEquals(0, vault.getAchievementsUnlocked());
    }
    
    @Test
    @DisplayName("Vault should initialize with provided values")
    void testParameterizedConstructor() {
        Vault customVault = new Vault(500, 1000, 5, 3);
        assertEquals(500, customVault.getCoins());
        assertEquals(1000, customVault.getTotalSaved());
        assertEquals(5, customVault.getQuestsCompleted());
        assertEquals(3, customVault.getAchievementsUnlocked());
    }
    
    @Test
    @DisplayName("UpdateSavings should add to coins and total saved")
    void testUpdateSavings() {
        vault.updateSavings(100);
        assertEquals(100, vault.getCoins());
        assertEquals(100, vault.getTotalSaved());
        
        vault.updateSavings(50);
        assertEquals(150, vault.getCoins());
        assertEquals(150, vault.getTotalSaved());
    }
    
    @Test
    @DisplayName("UpdateSavings with negative amount should not change values")
    void testUpdateSavingsNegative() {
        vault.updateSavings(100);
        vault.updateSavings(-50);
        assertEquals(100, vault.getCoins(), "Coins should not decrease with negative amount");
        assertEquals(100, vault.getTotalSaved());
    }
    
    @Test
    @DisplayName("UpdateCoins should modify coin count")
    void testUpdateCoins() {
        vault.updateCoins(100);
        assertEquals(100, vault.getCoins());
        
        vault.updateCoins(50);
        assertEquals(150, vault.getCoins());
        
        vault.updateCoins(-30);
        assertEquals(120, vault.getCoins());
    }
    
    @Test
    @DisplayName("SpendCoins should decrease coins successfully")
    void testSpendCoins() {
        vault.updateSavings(1000);
        assertTrue(vault.spendCoins(300));
        assertEquals(700, vault.getCoins());
        assertEquals(1000, vault.getTotalSaved(), "Total saved should not decrease");
    }
    
    @Test
    @DisplayName("SpendCoins should fail with insufficient funds")
    void testSpendCoinsInsufficientFunds() {
        vault.updateSavings(100);
        assertFalse(vault.spendCoins(200));
        assertEquals(100, vault.getCoins(), "Coins should not change on failed purchase");
    }
    
    @Test
    @DisplayName("SpendCoins should fail with negative or zero amount")
    void testSpendCoinsInvalidAmount() {
        vault.updateSavings(100);
        assertFalse(vault.spendCoins(-50));
        assertFalse(vault.spendCoins(0));
        assertEquals(100, vault.getCoins());
    }
    
    @Test
    @DisplayName("CompleteQuest should increment quest counter")
    void testCompleteQuest() {
        assertEquals(0, vault.getQuestsCompleted());
        vault.completeQuest();
        assertEquals(1, vault.getQuestsCompleted());
        vault.completeQuest();
        vault.completeQuest();
        assertEquals(3, vault.getQuestsCompleted());
    }
    
    @Test
    @DisplayName("UnlockAchievement should increment achievement counter")
    void testUnlockAchievement() {
        assertEquals(0, vault.getAchievementsUnlocked());
        vault.unlockAchievement();
        assertEquals(1, vault.getAchievementsUnlocked());
        vault.unlockAchievement();
        assertEquals(2, vault.getAchievementsUnlocked());
    }
    
    @Test
    @DisplayName("GetSavingsRate should calculate correctly")
    void testGetSavingsRate() {
        vault.updateSavings(1000);
        assertEquals(100.0, vault.getSavingsRate(), 0.01);
        
        vault.spendCoins(250);
        assertEquals(75.0, vault.getSavingsRate(), 0.01);
    }
    
    @Test
    @DisplayName("GetSavingsRate should return 0 when totalSaved is 0")
    void testGetSavingsRateZero() {
        assertEquals(0.0, vault.getSavingsRate(), 0.01);
    }
    
    @Test
    @DisplayName("GenerateReport should contain all vault data")
    void testGenerateReport() {
        vault.updateSavings(5000);
        vault.completeQuest();
        vault.unlockAchievement();
        
        String report = vault.generateReport("Weekly");
        
        assertTrue(report.contains("WEEKLY"));
        assertTrue(report.contains("5,000"));
        assertTrue(report.contains("Quests Completed:         1"));
        assertTrue(report.contains("Achievements Unlocked:    1"));
    }
    
    @Test
    @DisplayName("GetSummary should return formatted string")
    void testGetSummary() {
        vault.updateSavings(1500);
        vault.completeQuest();
        vault.unlockAchievement();
        
        String summary = vault.getSummary();
        assertTrue(summary.contains("1,500"));
        assertTrue(summary.contains("Quests: 1"));
        assertTrue(summary.contains("Achievements: 1"));
    }
    
    @Test
    @DisplayName("ToString should return formatted vault information")
    void testToString() {
        vault.updateSavings(2000);
        vault.completeQuest();
        vault.unlockAchievement();
        
        String str = vault.toString();
        assertTrue(str.contains("Vault"));
        assertTrue(str.contains("2,000"));
        assertTrue(str.contains("quests=1"));
        assertTrue(str.contains("achievements=1"));
    }
    
    @ParameterizedTest
    @ValueSource(ints = {100, 500, 1000, 5000, 10000})
    @DisplayName("Vault should handle various saving amounts")
    void testVariousSavingAmounts(int amount) {
        vault.updateSavings(amount);
        assertEquals(amount, vault.getCoins());
        assertEquals(amount, vault.getTotalSaved());
    }
    
    @Test
    @DisplayName("Setters should update vault values correctly")
    void testSetters() {
        vault.setCoins(500);
        vault.setTotalSaved(1000);
        vault.setQuestsCompleted(10);
        vault.setAchievementsUnlocked(5);
        
        assertEquals(500, vault.getCoins());
        assertEquals(1000, vault.getTotalSaved());
        assertEquals(10, vault.getQuestsCompleted());
        assertEquals(5, vault.getAchievementsUnlocked());
    }
}
