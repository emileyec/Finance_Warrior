/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package FinanceWarriorTestPackage;

/**
 *
 * @author jemim
 */
import Armory.Armory;
import Armory.Equipment;
import Armory.EquipmentIterator;
import Armory.EquipmentType;
import Armory.SortByCost;
import Armory.SortByType;
import Armory.SortByUnlocked;
import Levels.Vault;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

/**
 * Unit tests for Armory class
 */
@DisplayName("Armory Tests")
class ArmoryTest {
    
    private Armory armory;
    private Vault vault;
    private Equipment sword;
    private Equipment shield;
    private Equipment armor;
    private Equipment boots;
    
    @BeforeEach
    void setUp() {
        vault = new Vault();
        vault.updateCoins(1000);
        armory = new Armory(vault);
        
        sword = new Equipment("Iron Sword", 50, EquipmentType.WEAPON);
        shield = new Equipment("Steel Shield", 100, EquipmentType.SHIELD);
        armor = new Equipment("Leather Armor", 75, EquipmentType.ARMOR);
        boots = new Equipment("Iron Boots", 80, EquipmentType.FOOTWEAR);
    }
    
    @Test
    @DisplayName("Armory should initialize with vault")
    void testArmoryCreation() {
        assertNotNull(armory);
        assertEquals(vault, armory.getVault());
    }
    
    @Test
    @DisplayName("AddEquipment should add equipment to armory")
    void testAddEquipment() {
        armory.addEquipment(sword);
        armory.addEquipment(shield);
        
        EquipmentIterator iterator = armory.createIterator();
        int count = 0;
        while (iterator.hasNext()) {
            iterator.next();
            count++;
        }
        assertEquals(2, count);
    }
    
    @Test
    @DisplayName("CreateIterator should return AllEquipmentIterator by default")
    void testCreateIteratorDefault() {
        armory.addEquipment(sword);
        armory.addEquipment(shield);
        armory.addEquipment(armor);
        
        EquipmentIterator iterator = armory.createIterator();
        assertNotNull(iterator);
        
        int count = 0;
        while (iterator.hasNext()) {
            assertNotNull(iterator.next());
            count++;
        }
        assertEquals(3, count);
    }
    
    @Test
    @DisplayName("CreateIterator with SortByCost should return sorted list")
    void testCreateIteratorWithSortByCost() {
        armory.addEquipment(shield);  // 100
        armory.addEquipment(sword);   // 50
        armory.addEquipment(boots);   // 80
        
        armory.setSortStrategy(new SortByCost());
        EquipmentIterator iterator = armory.createIterator();
        
        Equipment first = iterator.next();
        Equipment second = iterator.next();
        Equipment third = iterator.next();
        
        assertEquals("Iron Sword", first.getName());
        assertEquals("Iron Boots", second.getName());
        assertEquals("Steel Shield", third.getName());
    }
    
    @Test
    @DisplayName("CreateIterator with SortByUnlocked should return only unlocked items")
    void testCreateIteratorWithSortByUnlocked() {
        armory.addEquipment(sword);
        armory.addEquipment(shield);
        armory.addEquipment(armor);
        
        // Unlock only sword and armor
        sword.unlockEquipment();
        armor.unlockEquipment();
        
        armory.setSortStrategy(new SortByUnlocked());
        EquipmentIterator iterator = armory.createIterator();
        
        int count = 0;
        while (iterator.hasNext()) {
            Equipment eq = iterator.next();
            assertTrue(eq.getStatus(), "Should only return unlocked equipment");
            count++;
        }
        assertEquals(2, count);
    }
    
    @Test
    @DisplayName("PurchaseEquipment should unlock equipment and deduct coins")
    void testPurchaseEquipment() {
        armory.addEquipment(sword);
        
        int initialCoins = vault.getCoins();
        assertFalse(sword.getStatus());
        
        armory.purchaseEquipment(sword);
        
        assertTrue(sword.getStatus());
        assertEquals(initialCoins - sword.getCost(), vault.getCoins());
    }
    
    @Test
    @DisplayName("PurchaseEquipment should fail with insufficient funds")
    void testPurchaseEquipmentInsufficientFunds() {
        vault.setCoins(30); // Not enough for sword (50)
        armory.addEquipment(sword);
        
        assertFalse(sword.getStatus());
        armory.purchaseEquipment(sword);
        
        assertFalse(sword.getStatus(), "Equipment should not be unlocked");
        assertEquals(30, vault.getCoins(), "Coins should not be deducted");
    }
    
    @Test
    @DisplayName("PurchaseEquipment should not allow purchasing already unlocked equipment")
    void testPurchaseEquipmentAlreadyUnlocked() {
        armory.addEquipment(sword);
        sword.unlockEquipment();
        
        int initialCoins = vault.getCoins();
        armory.purchaseEquipment(sword);
        
        assertEquals(initialCoins, vault.getCoins(), "Coins should not be deducted for already unlocked equipment");
    }
    
    @Test
    @DisplayName("GetUnlockedItems should return only unlocked equipment")
    void testGetUnlockedItems() {
        armory.addEquipment(sword);
        armory.addEquipment(shield);
        armory.addEquipment(armor);
        armory.addEquipment(boots);
        
        sword.unlockEquipment();
        armor.unlockEquipment();
        
        ArrayList<Equipment> unlocked = armory.getUnlockedItems();
        assertEquals(2, unlocked.size());
        
        for (Equipment eq : unlocked) {
            assertTrue(eq.getStatus());
        }
    }
    
    @Test
    @DisplayName("GetUnlockedItems should return empty list when no items unlocked")
    void testGetUnlockedItemsEmpty() {
        armory.addEquipment(sword);
        armory.addEquipment(shield);
        
        ArrayList<Equipment> unlocked = armory.getUnlockedItems();
        assertTrue(unlocked.isEmpty());
    }
    
    @Test
    @DisplayName("GetSortedEquipment should return equipment sorted by strategy")
    void testGetSortedEquipment() {
        armory.addEquipment(shield);  // 100
        armory.addEquipment(sword);   // 50
        armory.addEquipment(armor);   // 75
        
        armory.setSortStrategy(new SortByCost());
        ArrayList<Equipment> sorted = armory.getSortedEquipment();
        
        assertEquals(3, sorted.size());
        assertEquals("Iron Sword", sorted.get(0).getName());
        assertEquals("Leather Armor", sorted.get(1).getName());
        assertEquals("Steel Shield", sorted.get(2).getName());
    }
    
    @Test
    @DisplayName("SetSortStrategy should change sorting behavior")
    void testSetSortStrategy() {
        Equipment helmet = new Equipment("Iron Helmet", 70, EquipmentType.HELMET);
        
        armory.addEquipment(sword);    // WEAPON
        armory.addEquipment(shield);   // SHIELD
        armory.addEquipment(helmet);   // HELMET
        
        // Test with SortByType
        armory.setSortStrategy(new SortByType());
        ArrayList<Equipment> sortedByType = armory.getSortedEquipment();
        assertNotNull(sortedByType);
        
        // Test with SortByCost
        armory.setSortStrategy(new SortByCost());
        ArrayList<Equipment> sortedByCost = armory.getSortedEquipment();
        assertNotNull(sortedByCost);
    }
    
    @Test
    @DisplayName("Multiple purchases should correctly update vault")
    void testMultiplePurchases() {
        armory.addEquipment(sword);   // 50
        armory.addEquipment(armor);   // 75
        
        int initialCoins = vault.getCoins();
        
        armory.purchaseEquipment(sword);
        armory.purchaseEquipment(armor);
        
        assertTrue(sword.getStatus());
        assertTrue(armor.getStatus());
        assertEquals(initialCoins - 50 - 75, vault.getCoins());
    }
}