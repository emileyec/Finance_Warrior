/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package FinanceWarriorTestPackage;

/**
 *
 * @author jemim
 */
import org.junit.platform.suite.api.SelectPackages;
import org.junit.platform.suite.api.Suite;
import org.junit.platform.suite.api.SuiteDisplayName;

/**
 * Test Suite for Finance Warrior Application
 * Runs all unit tests across all packages
 * 
 * To run all tests:
 * mvn test
 * 
 * To run specific package:
 * mvn test -Dtest=Armory.*Test
 * mvn test -Dtest=Warrior.*Test
 * mvn test -Dtest=Levels.*Test
 * mvn test -Dtest=Events.*Test
 */
@Suite
@SuiteDisplayName("Finance Warrior Tests")
@SelectPackages({"Armory", "Warrior", "Levels", "Events"})
public class FinanceWarriorTest {
    // This class serves as a test suite runner
    // All tests in the selected packages will be executed
}
