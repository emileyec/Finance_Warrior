/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package FinanceWarriorTestPackage;

import Armory.Equipment;
import Armory.EquipmentType;
import Levels.Level;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Level class
 * @author jemim
 */

@DisplayName("Level Tests")
class LevelTest {
    
    private Level level;
    private Equipment sword;
    private Equipment shield;
    private Equipment armor;
    
    @BeforeEach
    void setUp() {
        level = new Level();
        sword = new Equipment("Iron Sword", 100, EquipmentType.WEAPON);
        shield = new Equipment("Wooden Shield", 75, EquipmentType.SHIELD);
        armor = new Equipment("Leather Armor", 150, EquipmentType.ARMOR);
    }
    
    @Test
    @DisplayName("Default constructor should initialize with zero values")
    void testDefaultConstructor() {
        assertEquals(0, level.getXpNeeded());
        assertEquals(0, level.getXpEarned());
        assertEquals(0, level.getRewards().length);
        assertEquals(1, level.getLvl());
    }
    
    @Test
    @DisplayName("Constructor with XP should set XP needed")
    void testConstructorWithXP() {
        Level level2 = new Level(1000);
        assertEquals(1000, level2.getXpNeeded());
        assertEquals(0, level2.getXpEarned());
        assertEquals(0, level2.getRewards().length);
    }
    
    @Test
    @DisplayName("Constructor with XP and rewards should initialize correctly")
    void testConstructorWithRewards() {
        Equipment[] rewards = {sword, shield};
        Level level3 = new Level(500, rewards);
        assertEquals(500, level3.getXpNeeded());
        assertEquals(0, level3.getXpEarned());
        assertEquals(2, level3.getRewards().length);
    }
    
    @Test
    @DisplayName("Constructor should handle null rewards array")
    void testConstructorWithNullRewards() {
        Level level4 = new Level(500, null);
        assertEquals(0, level4.getRewards().length);
    }
    
    @Test
    @DisplayName("UpdateXp should set XP earned")
    void testUpdateXp() {
        level.setXpNeeded(1000);
        level.updateXp(250);
        assertEquals(250, level.getXpEarned());
        
        level.updateXp(500);
        assertEquals(500, level.getXpEarned());
    }
    
    @Test
    @DisplayName("IsComplete should return true when XP requirement is met")
    void testIsComplete() {
        level.setXpNeeded(1000);
        level.updateXp(500);
        assertFalse(level.isComplete());
        
        level.updateXp(1000);
        assertTrue(level.isComplete());
        
        level.updateXp(1500);
        assertTrue(level.isComplete());
    }
    
    @Test
    @DisplayName("GetProgress should calculate percentage correctly")
    void testGetProgress() {
        level.setXpNeeded(1000);
        
        level.updateXp(0);
        assertEquals(0.0, level.getProgress(), 0.01);
        
        level.updateXp(250);
        assertEquals(25.0, level.getProgress(), 0.01);
        
        level.updateXp(500);
        assertEquals(50.0, level.getProgress(), 0.01);
        
        level.updateXp(1000);
        assertEquals(100.0, level.getProgress(), 0.01);
    }
    
    @Test
    @DisplayName("GetProgress should cap at 100% for over-earned XP")
    void testGetProgressOverflow() {
        level.setXpNeeded(1000);
        level.updateXp(1500);
        assertEquals(100.0, level.getProgress(), 0.01);
    }
    
    @Test
    @DisplayName("GetProgress should return 100 when XP needed is 0")
    void testGetProgressZeroNeeded() {
        level.setXpNeeded(0);
        level.updateXp(100);
        assertEquals(100.0, level.getProgress(), 0.01);
    }
    
    @Test
    @DisplayName("GetXpRemaining should calculate correctly")
    void testGetXpRemaining() {
        level.setXpNeeded(1000);
        
        level.updateXp(0);
        assertEquals(1000, level.getXpRemaining());
        
        level.updateXp(300);
        assertEquals(700, level.getXpRemaining());
        
        level.updateXp(1000);
        assertEquals(0, level.getXpRemaining());
    }
    
    @Test
    @DisplayName("GetXpRemaining should not return negative values")
    void testGetXpRemainingNonNegative() {
        level.setXpNeeded(1000);
        level.updateXp(1500);
        assertEquals(0, level.getXpRemaining());
    }
    
    @Test
    @DisplayName("LevelUp should unlock all rewards and reset XP")
    void testLevelUp() {
        Equipment[] rewards = {sword, shield, armor};
        level.setRewards(rewards);
        level.setXpNeeded(1000);
        level.updateXp(1000);
        
        assertFalse(sword.getStatus());
        assertFalse(shield.getStatus());
        assertFalse(armor.getStatus());
        
        Equipment[] earnedRewards = level.levelUp();
        
        assertTrue(sword.getStatus());
        assertTrue(shield.getStatus());
        assertTrue(armor.getStatus());
        assertEquals(3, earnedRewards.length);
        assertEquals(0, level.getXpEarned());
    }
    
    @Test
    @DisplayName("LevelUp with no rewards should work correctly")
    void testLevelUpNoRewards() {
        level.setXpNeeded(1000);
        level.updateXp(1000);
        
        Equipment[] earnedRewards = level.levelUp();
        assertEquals(0, earnedRewards.length);
        assertEquals(0, level.getXpEarned());
    }
    
    @Test
    @DisplayName("ShowReward should return rewards without unlocking")
    void testShowReward() {
        Equipment[] rewards = {sword, shield};
        level.setRewards(rewards);
        
        Equipment[] preview = level.showReward();
        assertEquals(2, preview.length);
        assertFalse(sword.getStatus(), "Rewards should not be unlocked by showReward");
        assertFalse(shield.getStatus());
    }
    
    @Test
    @DisplayName("AddReward should add equipment to rewards")
    void testAddReward() {
        assertEquals(0, level.getRewardCount());
        
        level.addReward(sword);
        assertEquals(1, level.getRewardCount());
        
        level.addReward(shield);
        assertEquals(2, level.getRewardCount());
        
        level.addReward(armor);
        assertEquals(3, level.getRewardCount());
    }
    
    @Test
    @DisplayName("AddReward should ignore null equipment")
    void testAddRewardNull() {
        level.addReward(sword);
        assertEquals(1, level.getRewardCount());
        
        level.addReward(null);
        assertEquals(1, level.getRewardCount(), "Null reward should not be added");
    }
    
    @Test
    @DisplayName("GetRewardCount should return correct count")
    void testGetRewardCount() {
        Equipment[] rewards = {sword, shield, armor};
        level.setRewards(rewards);
        assertEquals(3, level.getRewardCount());
    }
    
    @Test
    @DisplayName("GetTotalRewardValue should sum all equipment costs")
    void testGetTotalRewardValue() {
        Equipment[] rewards = {sword, shield, armor};
        level.setRewards(rewards);
        
        int expected = 100 + 75 + 150; // 325
        assertEquals(expected, level.getTotalRewardValue());
    }
    
    @Test
    @DisplayName("GetTotalRewardValue should return 0 for no rewards")
    void testGetTotalRewardValueEmpty() {
        assertEquals(0, level.getTotalRewardValue());
    }
    
    @Test
    @DisplayName("Setters should update level properties")
    void testSetters() {
        level.setXpNeeded(5000);
        level.setXpEarned(2500);
        level.setLvl(10);
        
        assertEquals(5000, level.getXpNeeded());
        assertEquals(2500, level.getXpEarned());
        assertEquals(10, level.getLvl());
    }
    
    @Test
    @DisplayName("ToString should contain level information")
    void testToString() {
        level.setXpNeeded(1000);
        level.setXpEarned(500);
        Equipment[] rewards = {sword, shield};
        level.setRewards(rewards);
        
        String str = level.toString();
        assertTrue(str.contains("Level"));
        assertTrue(str.contains("xpNeeded=1000"));
        assertTrue(str.contains("xpEarned=500"));
        assertTrue(str.contains("50.0%"));
        assertTrue(str.contains("rewards=2"));
    }
}