/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package FinanceWarriorTestPackage;

import Armory.AllEquipmentIterator;
import Armory.Equipment;
import Armory.EquipmentIterator;
import Armory.EquipmentType;
import Armory.UnlockedOnlyIterator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.NoSuchElementException;

/**
 *Unit tests for Equipment Iterators
 * @author jemim
 */

@DisplayName("Equipment Iterator Tests")
public class EquipmentIteratorTest {
    
    private ArrayList<Equipment> equipmentList;
    private Equipment sword;
    private Equipment shield;
    private Equipment armor;
    
    @BeforeEach
    void setUp() {
        equipmentList = new ArrayList<>();
        
        sword = new Equipment("Iron Sword", 50, EquipmentType.WEAPON);
        shield = new Equipment("Steel Shield", 100, EquipmentType.SHIELD);
        armor = new Equipment("Leather Armor", 75, EquipmentType.ARMOR);
        
        equipmentList.add(sword);
        equipmentList.add(shield);
        equipmentList.add(armor);
    }
    
    @Test
    @DisplayName("AllEquipmentIterator should iterate through all items")
    void testAllEquipmentIterator() {
        EquipmentIterator iterator = new AllEquipmentIterator(equipmentList);
        
        int count = 0;
        while (iterator.hasNext()) {
            assertNotNull(iterator.next());
            count++;
        }
        
        assertEquals(3, count);
    }
    
    @Test
    @DisplayName("AllEquipmentIterator should return items in order")
    void testAllEquipmentIteratorOrder() {
        EquipmentIterator iterator = new AllEquipmentIterator(equipmentList);
        
        assertTrue(iterator.hasNext());
        assertEquals(sword, iterator.next());
        
        assertTrue(iterator.hasNext());
        assertEquals(shield, iterator.next());
        
        assertTrue(iterator.hasNext());
        assertEquals(armor, iterator.next());
        
        assertFalse(iterator.hasNext());
    }
    
    @Test
    @DisplayName("AllEquipmentIterator should handle empty list")
    void testAllEquipmentIteratorEmpty() {
        ArrayList<Equipment> emptyList = new ArrayList<>();
        EquipmentIterator iterator = new AllEquipmentIterator(emptyList);
        
        assertFalse(iterator.hasNext());
    }
    
    @Test
    @DisplayName("AllEquipmentIterator next should throw exception when no more elements")
    void testAllEquipmentIteratorNoSuchElement() {
        ArrayList<Equipment> singleList = new ArrayList<>();
        singleList.add(sword);
        
        EquipmentIterator iterator = new AllEquipmentIterator(singleList);
        
        assertTrue(iterator.hasNext());
        iterator.next();
        assertFalse(iterator.hasNext());
    }
    
    @Test
    @DisplayName("UnlockedOnlyIterator should only iterate unlocked items")
    void testUnlockedOnlyIterator() {
        sword.unlockEquipment();
        armor.unlockEquipment();
        // shield remains locked
        
        ArrayList<Equipment> unlockedList = new ArrayList<>();
        for (Equipment eq : equipmentList) {
            if (eq.getStatus()) {
                unlockedList.add(eq);
            }
        }
        
        EquipmentIterator iterator = new UnlockedOnlyIterator(unlockedList);
        
        int count = 0;
        while (iterator.hasNext()) {
            Equipment eq = iterator.next();
            assertTrue(eq.getStatus(), "Should only iterate unlocked equipment");
            count++;
        }
        
        assertEquals(2, count);
    }
    
    @Test
    @DisplayName("UnlockedOnlyIterator should return empty when no unlocked items")
    void testUnlockedOnlyIteratorEmpty() {
        ArrayList<Equipment> emptyUnlocked = new ArrayList<>();
        EquipmentIterator iterator = new UnlockedOnlyIterator(emptyUnlocked);
        
        assertFalse(iterator.hasNext());
    }
    
    @Test
    @DisplayName("UnlockedOnlyIterator should handle all items locked")
    void testUnlockedOnlyIteratorAllLocked() {
        // All equipment is locked by default
        ArrayList<Equipment> noUnlocked = new ArrayList<>();
        
        EquipmentIterator iterator = new UnlockedOnlyIterator(noUnlocked);
        assertFalse(iterator.hasNext());
    }
    
    @Test
    @DisplayName("UnlockedOnlyIterator should iterate all when all unlocked")
    void testUnlockedOnlyIteratorAllUnlocked() {
        sword.unlockEquipment();
        shield.unlockEquipment();
        armor.unlockEquipment();
        
        EquipmentIterator iterator = new UnlockedOnlyIterator(equipmentList);
        
        int count = 0;
        while (iterator.hasNext()) {
            assertTrue(iterator.next().getStatus());
            count++;
        }
        
        assertEquals(3, count);
    }
    
    @Test
    @DisplayName("Iterator should work with single item")
    void testIteratorSingleItem() {
        ArrayList<Equipment> singleList = new ArrayList<>();
        singleList.add(sword);
        
        EquipmentIterator iterator = new AllEquipmentIterator(singleList);
        
        assertTrue(iterator.hasNext());
        assertEquals(sword, iterator.next());
        assertFalse(iterator.hasNext());
    }
    
    @Test
    @DisplayName("Multiple iterators should be independent")
    void testMultipleIteratorsIndependent() {
        EquipmentIterator iterator1 = new AllEquipmentIterator(equipmentList);
        EquipmentIterator iterator2 = new AllEquipmentIterator(equipmentList);
        
        iterator1.next();
        iterator1.next();
        
        assertTrue(iterator2.hasNext());
        assertEquals(sword, iterator2.next());
    }
    
    @Test
    @DisplayName("Iterator should not be affected by original list changes after creation")
    void testIteratorSnapshot() {
        EquipmentIterator iterator = new AllEquipmentIterator(equipmentList);
        
        int count = 0;
        while (iterator.hasNext()) {
            iterator.next();
            count++;
        }
        
        // Iterator should still have original 3 items
        assertEquals(3, count);
    }
 
    @Test
    @DisplayName("HasNext should not advance iterator")
    void testHasNextDoesNotAdvance() {
        EquipmentIterator iterator = new AllEquipmentIterator(equipmentList);
        
        assertTrue(iterator.hasNext());
        assertTrue(iterator.hasNext());
        assertTrue(iterator.hasNext());
        
        Equipment first = iterator.next();
        assertEquals(sword, first);
    }
    
    @Test
    @DisplayName("UnlockedOnlyIterator next should throw when no more elements")
    void testUnlockedIteratorNoSuchElement() {
        sword.unlockEquipment();
        ArrayList<Equipment> oneUnlocked = new ArrayList<>();
        oneUnlocked.add(sword);
        
        EquipmentIterator iterator = new UnlockedOnlyIterator(oneUnlocked);
        
        assertTrue(iterator.hasNext());
        iterator.next();
        assertFalse(iterator.hasNext());

    }
}
