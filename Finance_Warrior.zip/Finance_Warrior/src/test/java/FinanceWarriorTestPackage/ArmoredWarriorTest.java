/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package FinanceWarriorTestPackage;

import Armory.Armory;
import Armory.Equipment;
import Armory.EquipmentType;
import Events.QuestList;
import Levels.Level;
import Levels.Vault;
import Warrior.ArmoredWarrior;
import Warrior.BasicWarrior;
import Warrior.Warrior;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for ArmoredWarrior decorator
 * @author jemim
 */

@DisplayName("ArmoredWarrior Tests")
class ArmoredWarriorTest {
    
    private ArmoredWarrior armoredWarrior;
    private BasicWarrior baseWarrior;
    private Armory armory;
    private QuestList questList;
    private Level level;
    private Vault vault;
    
    @BeforeEach
    void setUp() {
        vault = new Vault();
        vault.updateCoins(1000);
        armory = new Armory(vault);
        questList = new QuestList();
        
        level = new Level();
        level.setLvl(5);
        
        baseWarrior = new BasicWarrior("TestWarrior", armory, level);
        armoredWarrior = new ArmoredWarrior(baseWarrior, armory, questList);
    }
    
    @Test
    @DisplayName("ArmoredWarrior should wrap BasicWarrior correctly")
    void testArmoredWarriorCreation() {
        assertNotNull(armoredWarrior);
        assertEquals("TestWarrior", armoredWarrior.getUsername());
        assertEquals(5, armoredWarrior.getLevel());
        assertEquals(armory, armoredWarrior.getArmory());
    }
    
    @Test
    @DisplayName("ArmoredWarrior should delegate getUsername to decorated warrior")
    void testGetUsername() {
        assertEquals(baseWarrior.getUsername(), armoredWarrior.getUsername());
    }
    
    @Test
    @DisplayName("ArmoredWarrior should delegate getLevel to decorated warrior")
    void testGetLevel() {
        assertEquals(baseWarrior.getLevel(), armoredWarrior.getLevel());
    }
    
    @Test
    @DisplayName("ArmoredWarrior should delegate addXP to decorated warrior")
    void testAddXP() {
        int initialLevel = armoredWarrior.getLevel();
        armoredWarrior.addXP(3);
        assertEquals(initialLevel + 3, armoredWarrior.getLevel());
        assertEquals(baseWarrior.getLevel(), armoredWarrior.getLevel());
    }
    
    @Test
    @DisplayName("BrowseEquipment should iterate through all equipment")
    void testBrowseEquipment() {
        Equipment sword = new Equipment("Iron Sword", 50, EquipmentType.WEAPON);
        Equipment shield = new Equipment("Steel Shield", 100, EquipmentType.SHIELD);
        
        armory.addEquipment(sword);
        armory.addEquipment(shield);
        
        assertDoesNotThrow(() -> armoredWarrior.browseEquipment());
    }
    
    @Test
    @DisplayName("Customize should work for level 5+ warriors")
    void testCustomizeLevel5Plus() {
        Equipment sword = new Equipment("Iron Sword", 50, EquipmentType.WEAPON);
        Equipment shield = new Equipment("Steel Shield", 100, EquipmentType.SHIELD);
        
        armory.addEquipment(sword);
        armory.addEquipment(shield);
        
        sword.unlockEquipment();
        
        assertDoesNotThrow(() -> armoredWarrior.customize());
    }
    
    @Test
    @DisplayName("Customize should not work for warriors below level 5")
    void testCustomizeBelowLevel5() {
        Level lowLevel = new Level();
        lowLevel.setLvl(3);
        BasicWarrior lowLevelWarrior = new BasicWarrior("LowLevel", armory, lowLevel);
        ArmoredWarrior lowLevelArmored = new ArmoredWarrior(lowLevelWarrior, armory, questList);
        
        assertDoesNotThrow(() -> lowLevelArmored.customize());
        assertEquals(3, lowLevelArmored.getLevel());
    }
    
    @Test
    @DisplayName("GetActiveQuests should return quest list")
    void testGetActiveQuests() {
        QuestList returnedQuestList = armoredWarrior.getActiveQuests();
        assertEquals(questList, returnedQuestList);
        assertNotNull(returnedQuestList);
    }
    
    @Test
    @DisplayName("SetBackground should set background image path")
    void testSetBackground() {
        assertDoesNotThrow(() -> armoredWarrior.setBackground("test_background.jpg"));
    }
    
    @Test
    @DisplayName("GetArmory should return armory")
    void testGetArmory() {
        Armory returnedArmory = armoredWarrior.getArmory();
        assertEquals(armory, returnedArmory);
        assertNotNull(returnedArmory);
    }
    
    @Test
    @DisplayName("GetWarrior should return decorated warrior")
    void testGetWarrior() {
        Warrior decoratedWarrior = armoredWarrior.getWarrior();
        assertEquals(baseWarrior, decoratedWarrior);
    }
    
    @Test
    @DisplayName("Multiple decorations should work correctly")
    void testMultipleDecorations() {
        // Create a chain of decorations
        ArmoredWarrior firstArmored = new ArmoredWarrior(baseWarrior, armory, questList);
        ArmoredWarrior secondArmored = new ArmoredWarrior(firstArmored, armory, new QuestList());
        
        assertEquals("TestWarrior", secondArmored.getUsername());
        assertEquals(5, secondArmored.getLevel());
    }
    
    @Test
    @DisplayName("ArmoredWarrior should maintain level progression")
    void testLevelProgression() {
        int initialLevel = armoredWarrior.getLevel();
        
        armoredWarrior.addXP(1);
        assertEquals(initialLevel + 1, armoredWarrior.getLevel());
        
        armoredWarrior.addXP(4);
        assertEquals(initialLevel + 5, armoredWarrior.getLevel());
    }
    
    @Test
    @DisplayName("Customize should only show unlocked equipment")
    void testCustomizeShowsOnlyUnlocked() {
        Level highLevel = new Level();
        highLevel.setLvl(10);
        BasicWarrior highLevelWarrior = new BasicWarrior("HighLevel", armory, highLevel);
        ArmoredWarrior highLevelArmored = new ArmoredWarrior(highLevelWarrior, armory, questList);
        
        Equipment sword = new Equipment("Iron Sword", 50, EquipmentType.WEAPON);
        Equipment shield = new Equipment("Steel Shield", 100, EquipmentType.SHIELD);
        Equipment armor = new Equipment("Leather Armor", 75, EquipmentType.ARMOR);
        
        armory.addEquipment(sword);
        armory.addEquipment(shield);
        armory.addEquipment(armor);
        
        // Unlock only sword and armor
        sword.unlockEquipment();
        armor.unlockEquipment();
        
        assertDoesNotThrow(() -> highLevelArmored.customize());
    }
    
    @Test
    @DisplayName("ArmoredWarrior should work with empty armory")
    void testWithEmptyArmory() {
        Vault emptyVault = new Vault();
        Armory emptyArmory = new Armory(emptyVault);
        ArmoredWarrior emptyArmored = new ArmoredWarrior(baseWarrior, emptyArmory, questList);
        
        assertDoesNotThrow(() -> emptyArmored.browseEquipment());
        assertDoesNotThrow(() -> emptyArmored.customize());
    }
}

