/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Application;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 * A panel that allows user log in for the FWApp
 * @author emiley
 */
public class LoginView extends JPanel {
    private final LoginController controller;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;

    /**
     * Constructor for the LoginView
     * @param controller - login controller to handle validation
     */
    public LoginView(LoginController controller) {
        this.controller = controller;
        initUI();
    }

    /**
     * Sets up the UI for the log in
     */
    private void initUI() {
        setLayout(new BorderLayout());
        JPanel formPanel = new JPanel(new GridLayout(0, 1, 5, 5));

        usernameField = new JTextField();
        passwordField = new JPasswordField();

        formPanel.add(new JLabel("Username:"));
        formPanel.add(usernameField);
        formPanel.add(new JLabel("Password:"));
        formPanel.add(passwordField);

        loginButton = new JButton("Login");
        loginButton.addActionListener((ActionEvent e) -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            boolean success = controller.handleLogin(username, password);

            if (!success) {
                JOptionPane.showMessageDialog(this, "Invalid credentials.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        add(formPanel, BorderLayout.CENTER);
        add(loginButton, BorderLayout.SOUTH);
    }
}


