/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Application;
/**
 * Controller that manages the process of logging into the Financial Warrior app
 * @author emiley
 */
public class LoginController {
    private FWApp app;
    /**
     * Constructor of the LoginController
     * @param app - application to be shown after successful login
     */
    public LoginController(FWApp app) {
        this.app = app;
    }

    /**
     * Validates the login credentials
     * @param username - username inputted
     * @param password - password inputted
     * @return whether or not login was successful
     */
    public boolean handleLogin(String username, String password) {
        boolean ok = "admin".equals(username) && "password".equals(password);

        if (ok) {
            app.startApplication();
        }

        return ok;
    }
}
