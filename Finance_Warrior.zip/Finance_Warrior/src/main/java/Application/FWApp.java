/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Application;

import Levels.*;
import Events.*;
import Warrior.*;
import Armory.*;
import javax.swing.*;
import java.awt.*;
/**
 * The main application panel for the Financial Warrior application. 
 * It manages the application and brings all of the pieces together to create one coherent program.
 * The class represents a Singleton pattern where only one instance of the FWApp can be created and it is done so inside of itself.
 */
public class FWApp extends JPanel {
    //Single instance of the FWApp
    private static FWApp instance;

    // Main window
    private JFrame frame;

    // CardLayout for swapping screens
    private CardLayout cardLayout;

    // Panels
    private JPanel loginPanel;
    private JPanel mainMenuPanel;
    private JPanel warriorPanel;   // container for WarriorView

    //Concrete instances
    private Warrior currentWarrior;
    private Level lvl;
    private Armory armory;
    private QuestList quests;
    private Vault vault;

    /**
     * Constructor for the FWApp
     */
    public FWApp() {
        instance = this;

        // MAIN FRAME + CARD LAYOUT SETUP
        frame = new JFrame("Financial Warrior App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        cardLayout = new CardLayout();
        setLayout(cardLayout);

        // BUILD LOGIN SCREEN FIRST
        LoginController loginController = new LoginController(this);
        loginPanel = new LoginView(loginController);
        add(loginPanel, "login");

        // SHOW LOGIN FIRST
        frame.setContentPane(this);
        cardLayout.show(this, "login");
        frame.setVisible(true);
    }

    /**
     * Creates the basis for the application start
     * CALLED BY LoginController ON SUCCESSFUL LOGIN
     */
    public void startApplication() {

        // CReate vault
        Vault v = new Vault();
        v.updateCoins(1000);
        armory = new Armory(v);
        quests = new QuestList();
        vault = v;
        populateArmory();
        
        //Create level
        Level lvl6 = new Level();
        lvl6.setLvl(6);
        
        // Start with ArmoredWarrior (unchanged)
        BasicWarrior baseWarrior = new BasicWarrior("Jeremy", armory, lvl6);
        currentWarrior = new ArmoredWarrior(baseWarrior, armory, quests);
        
        //set lvl6 to the level of the warrior
        lvl6.setLvl(currentWarrior.getLevel());
        lvl = lvl6;
        
        // Build main menu after login
        buildMainMenu();
        add(mainMenuPanel, "main");

        // SWITCH FROM LOGIN TO MAIN MENU
        cardLayout.show(this, "main");
    }

    /**
     * Builds main menu panel with quests, warrior, and vault
     */ 
    private void buildMainMenu() {
        mainMenuPanel = new JPanel();
        mainMenuPanel.setLayout(new BorderLayout());
        JPanel buttonRow = new JPanel(new GridLayout(1, 3, 20, 0));
        JButton questsButton = new JButton("Quests");
        JButton warriorButton = new JButton("Warrior");
        JButton vaultButton = new JButton("Vault");

        // Open QuestListView
        questsButton.addActionListener(e -> openQuestListView());

        // Open Warrior screen
        warriorButton.addActionListener(e -> openWarriorView());

        // Open FinancialSummaryView in its own window
        vaultButton.addActionListener(e -> openFinancialSummary());

        buttonRow.add(questsButton);
        buttonRow.add(warriorButton);
        buttonRow.add(vaultButton);
        mainMenuPanel.add(buttonRow, BorderLayout.CENTER);

        // LOGOUT
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton logoutButton = new JButton("Log Out");
        logoutButton.addActionListener(e -> {
            cardLayout.show(this, "login");
        });
        bottomPanel.add(logoutButton);
        mainMenuPanel.add(bottomPanel, BorderLayout.SOUTH);
    }

    /**
     * Opens the financial summary in a new window
     */ 
    private void openFinancialSummary() {
    // Create the view
    FinancialSummaryView view = new FinancialSummaryView();
    //controller
    FinancialSummaryController controller = new FinancialSummaryController(this, view) {
        @Override
        public void requestSummary(String timeframe) {
            // Example summary data
            String summary = "========================================\n" +
                             "   FINANCIAL SUMMARY - " + timeframe.toUpperCase() + "\n" +
                             "========================================\n" +
                             "Total Coins:           " + armory.getVault().getCoins() + "\n" +
                             "Quests Completed:      " + vault.getQuestsCompleted() + "\n" +
                             "Achievements Unlocked: " + vault.getAchievementsUnlocked() + "\n" +
                             "========================================\n";
            view.updateSummary(summary);
            }
        };

        view.setController(controller);
        controller.initializeView();
        view.setVisible(true);
    }


    /**
     * Opens the warrior view as a JPanel
     */ 
    private void openWarriorView() {
        if (currentWarrior.getLevel() >= 5 && !(currentWarrior instanceof ArmoredWarrior)) {
            currentWarrior = new ArmoredWarrior(currentWarrior, armory, quests);
        }

        WarriorController controller =
            new WarriorController(null, currentWarrior, this, armory);
        WarriorView warriorView = new WarriorView(currentWarrior, controller);
        controller.setWarriorView(warriorView);

        if (warriorPanel != null) {
            remove(warriorPanel);
        }
        warriorPanel = warriorView;
        add(warriorPanel, "warrior");
        cardLayout.show(this, "warrior");
    }
    
    /**
     * Opens quest list view in its own window
     */ 
    private void openQuestListView() {
        QuestListView questView = new QuestListView();
        QuestListController controller = new QuestListController(
            quests,
            questView,
            lvl,
            armory.getVault()
        );
        questView.setController(controller);

        // JFrame holds the Panel
        JFrame questFrame = new JFrame("Quest List");
        questFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        questFrame.setSize(600, 400);
        questFrame.setContentPane(questView);
        questFrame.setVisible(true);
    }
    
    /**
     * Switch panels generally
     * @param panel - panel to be displayed
     */ 
    public void showPanel(JPanel panel) {
        String name = panel.getClass().getSimpleName();
        add(panel, name);
        cardLayout.show(this, name);
    }

    /**
     * Switch back to main menu
     */
    public void showMain() {
        cardLayout.show(this, "main");
    }


    /**
     * Populate Armory with sample equipment items for testing/demo use
     */ 
    private void populateArmory() {
        armory.addEquipment(new Equipment("Iron Sword", 50, EquipmentType.WEAPON));
        armory.addEquipment(new Equipment("Steel Sword", 120, EquipmentType.WEAPON));

        armory.addEquipment(new Equipment("Wooden Shield", 40, EquipmentType.SHIELD));
        armory.addEquipment(new Equipment("Steel Shield", 100, EquipmentType.SHIELD));

        armory.addEquipment(new Equipment("Leather Armor", 60, EquipmentType.ARMOR));
        armory.addEquipment(new Equipment("Steel Armor", 150, EquipmentType.ARMOR));

        armory.addEquipment(new Equipment("Leather Boots", 30, EquipmentType.FOOTWEAR));
        armory.addEquipment(new Equipment("Iron Boots", 80, EquipmentType.FOOTWEAR));

        armory.addEquipment(new Equipment("Iron Helmet", 70, EquipmentType.HELMET));
        armory.addEquipment(new Equipment("Steel Helmet", 130, EquipmentType.HELMET));

        armory.addEquipment(new Equipment("Golden Gauntlets", 200, EquipmentType.GAUNTLET));
        armory.addEquipment(new Equipment("Silver Gauntlets", 120, EquipmentType.GAUNTLET));

        armory.addEquipment(new Equipment("Magic Ring", 250, EquipmentType.ACCESSORY));
        armory.addEquipment(new Equipment("Amulet of Power", 300, EquipmentType.ACCESSORY));

        armory.addEquipment(new Equipment("Iron Torso Plate", 180, EquipmentType.TORSO));
    }

    /**
     * Main method to run the application
     * @param args - ignored
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(FWApp::new);
    }
}


