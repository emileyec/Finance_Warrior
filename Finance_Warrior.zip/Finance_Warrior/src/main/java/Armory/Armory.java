/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Armory;
import Levels.*;
import java.util.*;

/**
 * Represents the collection of all equipment available to the warrior
 * @author Nishat Shaneen
 */
public class Armory {
    private ArrayList<Equipment> equipmentList = new ArrayList<>();
    private EquipmentSortStrategy layoutStrategy;
    private Vault vault;  // you MUST inject or pass the Vault

    /**
     * Constructs an armory object
     * @param v - vault used to purchase equipment
     */
    public Armory(Vault v) {
        this.vault = v;
    }

    /**
     * Adds a new equipment item to the armory
     * @param e equipment being added to the Armory
     */
    public void addEquipment(Equipment e) {
        equipmentList.add(e);
    }

    /**
     * Sets the sort strategy for the equipment to be displayed
     * @param s strategy being used to sort the equipment
     */
    public void setSortStrategy(EquipmentSortStrategy s) {
        layoutStrategy = s;
    }

    /**
     * Creates an iterator for the equipment list depending on the selected sort strategy
     * @return iterator depending on sort type 
     */
    public EquipmentIterator createIterator() {
        if (layoutStrategy == null) {
            return new AllEquipmentIterator(equipmentList);
        }

        // If SortByUnlocked → return unlocked iterator
        if (layoutStrategy instanceof SortByUnlocked) {
            return new UnlockedOnlyIterator(getUnlockedItems());
        }

        // Otherwise use strategy-sorted list
        ArrayList<Equipment> sortedList = layoutStrategy.sort(equipmentList);
        return new AllEquipmentIterator(sortedList);
    }

    /**
     * Handles purchasing of equipment using coins stored in the vault
     * @param e  Equipment that is being purchased
     */
    public void purchaseEquipment(Equipment e) {
        if (e.getStatus()) {
            System.out.println("Equipment has already been unlocked.");
            return;
        }
        int coins = vault.getCoins();
        if (coins >= e.getCost()) {
            vault.updateCoins(-e.getCost());
            e.unlockEquipment();
            System.out.println(e.getName() + " purchased!");
        } else {
            System.out.println("Not enough coins. Save more!");
        }
    }

    /**
     * Retrieves all equipment items that the player has unlocked
     * @return unlocked - equipment in the list that have been unlocked
     */
    public ArrayList<Equipment> getUnlockedItems() {
        ArrayList<Equipment> unlocked = new ArrayList<>();
        for (Equipment eq : equipmentList) {
            if (eq.getStatus()) {
                unlocked.add(eq);
            }
        }
        return unlocked;
    }

    /**
     * Returns the equipment list after being sorted using the selected strategy
     * @return All the equipment sorted based on default or chosen type
     */
    public ArrayList<Equipment> getSortedEquipment() {
        return layoutStrategy.sort(equipmentList);
    }
   
    /**
     * Gets the Vault associated with this armory
     * @return vault - the player's vault
     */
    public Vault getVault() {
        return vault;
    }

}
