/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Armory;
import java.util.ArrayList;

/**
 * Interface for the sort classes - STRATEGY PATTERN
 * @author Nishat Shaneen
 */
public interface EquipmentSortStrategy {
    /**
     * Sorts a given list of equipment items based on a specific strategy
     * @param list - list of equipment to be sorted
     * @return sorted list 
     */
    ArrayList<Equipment> sort(ArrayList<Equipment> list);
}

