/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Armory;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/**
 * Acts as the controller in the MVC structure
 * Controller for coordinating interactions between the armory model and view
 * @author Nishat Shaneen
 */
public class ArmoryController {
    private Armory model;
    private ArmoryView view;

    /**
     * constructor for an ArmoryController model
     * @param model - Armory class
     * @param view - Armory view class
     */
    public ArmoryController(Armory model, ArmoryView view) {
        this.model = model;
        this.view = view;

        // Register listeners
        view.addSortListener(e -> handleSort());
        view.addPurchaseListener(e -> handlePurchase());
        view.addEquipListener(e -> handleEquip());

        // Display initial list
        view.updateEquipmentList(model.getSortedEquipment());
        view.updateCoins(model.getVault().getCoins());
    }

    /**
     *  Handles sorting when the user selects a sort option from the view
     */
    private void handleSort() {
        String option = view.getSelectedSortOption();
        switch (option) {
            case "Type":
                model.setSortStrategy(new SortByType());
                break;
            case "Cost":
                model.setSortStrategy(new SortByCost());
                break;
            case "Unlocked":
                model.setSortStrategy(new SortByUnlocked());
                break;
        }
        List<Equipment> sorted = model.getSortedEquipment();
        view.updateEquipmentList(sorted);
    }

    /**
     * Handles equipment purchases triggered by the view
     */
    private void handlePurchase() {
        Equipment selected = view.getSelectedEquipment();
        if (selected == null) return;
        model.purchaseEquipment(selected);
        List<Equipment> sorted = model.getSortedEquipment();
        view.updateEquipmentList(sorted);
        view.updateCoins(model.getVault().getCoins());
    }

    /**
     * Handles equipping an item
     */
    private void handleEquip() {
        Equipment selected = view.getSelectedEquipment();
        if (selected == null || !selected.getStatus()) return;
        view.addEquippedItem(selected);
        System.out.println("Equipped: " + selected.getName());
    }
}
