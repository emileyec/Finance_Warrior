/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Armory;

/**
 * Represents the different categories of equipment available in the Armory
 * Enum for the type of equipment made sense in this scenario rather than just a string
 * @author Nishat Shaneen
 */
public enum EquipmentType {
    /**
     * Represents weapons such as swords, bows, or daggers
     */
    WEAPON,
    
    /**
     * Represents protective body armor
     */
    ARMOR,
    
    /**
     * Represents footwear like boots or shoes
     */
    FOOTWEAR,
    
    /**
     * Represents headgear for protection
     */
    HELMET,
    
    /**
     * Represents shields used for defense
     */
    SHIELD,
    
    /**
     * Represents accessories such as rings, amulets, or necklaces
     */
    ACCESSORY,
    
    /**
     * Represents torso armor or clothing items
     */
    TORSO,
    
    /**
     * Represents protective gloves or gauntlets
     */
    GAUNTLET
}
