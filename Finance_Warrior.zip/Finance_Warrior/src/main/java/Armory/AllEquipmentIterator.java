/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Armory;
import java.util.ArrayList;

/**
 * Iterator that iterates through the array list that is passed in
 * @author Nishat Shaneen
 */
public class AllEquipmentIterator implements EquipmentIterator {
    private int index = 0;
    private ArrayList<Equipment> list;

    /**
     * Constructor for an iterator that will traverse the list
     * @param list - list that needs to be iterated - all equipment
     */
    public AllEquipmentIterator(ArrayList<Equipment> list) {
        this.list = list;
    }

    /**
     * Determines if there is another item in the list
     * @return Boolean value of whether the list has a value at the next index
     */
    @Override
    public boolean hasNext() {
        return index < list.size();
    }
    
    /**
     * Returns the next item in the list
     * @return Equipment - at the next index value
     */
    @Override
    public Equipment next() {
        return list.get(index++);
    }
}


