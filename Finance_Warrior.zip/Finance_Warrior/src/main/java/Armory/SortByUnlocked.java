/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Armory;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * Implements the EquipmentSortStrategy interface and sorts the equipment list to show only the unlocked items
 * @author Nishat Shaneen
 */
public class SortByUnlocked implements EquipmentSortStrategy {
    /**
     * Filters the given list of equipment to include only unlocked items
     * @param list - list to be sorted
     * @return list of only unlocked items
     */
    @Override
    public ArrayList<Equipment> sort(ArrayList<Equipment> list) {
        ArrayList<Equipment> unlocked = new ArrayList<>();
        for (Equipment e : list) {
            if (e.getStatus()) unlocked.add(e);
        }
        return unlocked;
    }
}
