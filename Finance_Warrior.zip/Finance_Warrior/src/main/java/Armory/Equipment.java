/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Armory;

/**
 * Represents an equipment item that can be purchased and equipped by the user
 * @author Nishat Shaneen
 */
public class Equipment {
    private String name;
    private int cost;
    private boolean unlocked = false;
    private EquipmentType type;
    
    /**
     * Constructor for a new equipment item
     * @param n - name of equipment
     * @param c - cost of equipment
     * @param t - type of equipment
     */
    public Equipment(String n, int c, EquipmentType t) {
        name = n;
        cost = c;
        type = t;
       
    }
    
    /**
     * Unlocks the equipment aka Purchased
     */
    public void unlockEquipment() {
        unlocked = true;
    }
    
    /**
     * Returns the cost of the item
     * @return cost of equipment
     */
    public int getCost() {
        return cost;
    }
    
    /**
     * Indicates if the equipment has been purchased
     * @return Boolean value of whether the equipment is unlocked
     */
    public boolean getStatus() {
        return unlocked;
    }
    
    /**
     * Returns the equipment's category
     * @return type of equipment - ENUM
     */
    public EquipmentType getType() {
        return type;
    }
    
    /**
     * Returns the equipment's display name
     * @return string name of equipment
     */
    public String getName() {
        return name;
    }
    
    /**
     * Returns a formatted string with name and cost of item
     * @return the equipment in a nice format of "Name ($cost)"
     */
    @Override
    public String toString() {
        return name + " (" + cost + ")";
    }
}
