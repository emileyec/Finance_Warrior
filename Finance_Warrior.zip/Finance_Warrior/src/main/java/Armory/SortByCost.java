/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Armory;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * Implements the EqupmentSortStrategy interface and sorts the equipment list by cost
 * @author Nishat Shaneen
 */
public class SortByCost implements EquipmentSortStrategy {
    /**
     * Sorts the given list of equipment by their cost in ascending order
     * @param list - list that needs to be sorted
     * @return - ArrayList that is sorted by cost of Equipment
     */
    @Override
    public ArrayList<Equipment> sort(ArrayList<Equipment> list) {
        ArrayList<Equipment> sorted = new ArrayList<>(list);

        Collections.sort(sorted, Comparator.comparingInt(Equipment::getCost));

        return sorted;
    }
}
