/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Armory;

/**
 * Interface for all the iterators - ITERATOR PATTERN
 * @author Nishat Shaneen
 */
public interface EquipmentIterator {
    /**
     * Determines whether another equipment items remain in the iteration
     * @return boolean value representing if there is another element
     */
    public boolean hasNext();
    
    /**
     * Returns the next equipment item in the sequence
     * @return the next item
     */
    public Equipment next();
    
}
