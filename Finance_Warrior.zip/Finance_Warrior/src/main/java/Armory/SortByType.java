/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Armory;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * Implements the EquipmentSortStrategyInterface and sorts the equipment list by type
 * @author Nishat Shaneen
 */
public class SortByType implements EquipmentSortStrategy {
    /**
     * Sorts the given list of equipment by type, and then by name within each type.
     * @param list - list that needs to be sorted
     * @return - ArrayList that is sorted by Equipment type
     */
    @Override
    public ArrayList<Equipment> sort(ArrayList<Equipment> list) {
        ArrayList<Equipment> sorted = new ArrayList<>(list);

        Collections.sort(sorted, Comparator
                .comparing(Equipment::getType)
                .thenComparing(Equipment::getName));

        return sorted;
    }
}
