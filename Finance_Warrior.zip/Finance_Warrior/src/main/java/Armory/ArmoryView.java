/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Armory;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;
import Warrior.*;
import Application.*;

/**
 * The visual component of the armory system
 * @author Nishat Shaneen
 */
public class ArmoryView extends JPanel {
    private final DefaultListModel<Equipment> equipmentListModel = new DefaultListModel<>();
    private final JList<Equipment> equipmentList = new JList<>(equipmentListModel);
    private final DefaultListModel<Equipment> equippedListModel = new DefaultListModel<>();
    private final JList<Equipment> equippedList = new JList<>(equippedListModel);
    private final JComboBox<String> sortOptions = new JComboBox<>(new String[]{"Type", "Cost", "Unlocked"});
    private final JButton purchaseButton = new JButton("Purchase");
    private final JButton equipButton = new JButton("Equip");
    private final JButton showWarriorButton = new JButton("Show Warrior");
    private final JLabel selectedEquipmentLabel = new JLabel("Selected: None");
    private final JLabel coinsLabel = new JLabel("Coins: 0");
    private final WarriorView warriorView;
    private final FWApp app;
    
    /**
     * Constructor for the ArmoryView
     * @param app - main application
     * @param warriorView  - the view that hold the warrior components
     */
    public ArmoryView(FWApp app, WarriorView warriorView) {
        this.app = app;
        this.warriorView = warriorView;
        setLayout(new BorderLayout());

        // Top Panel
        JPanel topPanel = new JPanel(new BorderLayout());
        JPanel sortPanel = new JPanel();
        sortPanel.add(new JLabel("Sort By:"));
        sortPanel.add(sortOptions);
        topPanel.add(sortPanel, BorderLayout.WEST);

        JPanel coinsPanel = new JPanel();
        coinsPanel.add(coinsLabel);
        topPanel.add(coinsPanel, BorderLayout.EAST);

        add(topPanel, BorderLayout.NORTH);

        // Lists
        JPanel centerPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        centerPanel.add(new JScrollPane(equipmentList));

        JScrollPane equippedScroll = new JScrollPane(equippedList);
        equippedList.setBorder(BorderFactory.createTitledBorder("Equipped Items"));
        centerPanel.add(equippedScroll);

        add(centerPanel, BorderLayout.CENTER);

        // BOTTOM BUTTON PANEL
        JPanel bottomPanel = new JPanel(new GridLayout(4, 1));
        bottomPanel.add(selectedEquipmentLabel);
        bottomPanel.add(purchaseButton);
        bottomPanel.add(equipButton);
        bottomPanel.add(showWarriorButton);

        add(bottomPanel, BorderLayout.SOUTH);

        // Listener for list selection
        equipmentList.addListSelectionListener(e -> {
            Equipment eq = equipmentList.getSelectedValue();
            if (eq != null) {
                selectedEquipmentLabel.setText("Selected: " + eq.getName());
                purchaseButton.setEnabled(!eq.getStatus());
                equipButton.setEnabled(eq.getStatus());
            }
        });

        // Listener for “SHOW WARRIOR”
        showWarriorButton.addActionListener(e -> {
            app.showPanel(warriorView);
        });
    }

    /**
     * Updates the equipment list displayed in the armory
     * @param list - list that must be updated in view
     */
    public void updateEquipmentList(List<Equipment> list) {
        equipmentListModel.clear();
        list.forEach(equipmentListModel::addElement);
    }

    /**
     * Adds an item to the equipped-items display list
     * @param e equipment to add to the equipped list
     */
    public void addEquippedItem(Equipment e) {
        equippedListModel.addElement(e);
    }

    /**
     * Returns the equipment item selected by the user
     * @return the selected equipment
     */
    public Equipment getSelectedEquipment() {
        return equipmentList.getSelectedValue();
    }

    /**
     * Retrieves the selected sorting option
     * @return String of the sort option selected by user
     */
    public String getSelectedSortOption() {
        return (String) sortOptions.getSelectedItem();
    }

    // ALL THE LISTENERS
    
    /**
     * Adds a listener that triggers when the sort option is changed
     * @param listener - the ActionListener to register
     */
    public void addSortListener(ActionListener listener) {
        sortOptions.addActionListener(listener);
    }

    /**
     * Adds a listener that triggers when the purchase button is pressed
     * @param listener - the ActionListener to register
     */
    public void addPurchaseListener(ActionListener listener) {
        purchaseButton.addActionListener(listener);
    }

    /**
     * Adds a listener that triggers when the equip button is pressed
     * @param listener - the ActionListener to register
     */
    public void addEquipListener(ActionListener listener) {
        equipButton.addActionListener(listener);
    }

    /**
     * Updates the coin display in the view
     * @param coins - updated view of the current coins
     */
    public void updateCoins(int coins) {
        coinsLabel.setText("Coins: " + coins);
    }
}
