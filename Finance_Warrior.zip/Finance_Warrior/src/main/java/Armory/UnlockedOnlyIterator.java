/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Armory;
import java.util.ArrayList;

/**
 * Iterator that iterates over a list of Equipment objects and returns only the unlocked items
 * This iterator is used mainly for the customize screen which shows the user only unlocked items
 * @author Nishat Shaneen
 */
public class UnlockedOnlyIterator implements EquipmentIterator {
    private int index = 0;
    private ArrayList<Equipment> unlockedList;
    
    /**
     * constructor for an iterator over a list of only unlocked equipment
     * @param unlockedList- List that needs to be iterated over - only unlocked equipment
     */
    public UnlockedOnlyIterator(ArrayList<Equipment> unlockedList) {
        this.unlockedList = unlockedList;
    }
    
    /**
     * Checks if there is a next element in the unlocked equipment list
     * @return Boolean value of whether the list has a value at the next index
     */
    @Override
    public boolean hasNext() {
        return index < unlockedList.size();
    }

    /**
     * Returns the next unlocked equipment in the iteration
     * @return Equipment at the next index value
     */
    @Override
    public Equipment next() {
        return unlockedList.get(index++);
    }
}

