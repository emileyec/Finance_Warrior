/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

package Levels;

/**
 *
 * @author Jemima Gay
 */
public interface Observer {
    /**
     * 
     * 
     * @param xp
     */
    void update(int xp);
}
