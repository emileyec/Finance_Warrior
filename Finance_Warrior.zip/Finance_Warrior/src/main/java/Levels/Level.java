/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Levels;

import Armory.Equipment;
import Armory.EquipmentType;

/**
 *
 * @author Jemima Gay
 */
public class Level {
    //attributes
    private int xpNeeded;
    private int xpEarned;
    private Equipment[] rewards;
    private int lvl = 1;
    
    //constructors
    public Level() {
        this.xpNeeded = 0;
        this.xpEarned = 0;
        this.rewards = new Equipment[0];
    }
    
    public Level(int xpNeeded) {
        this.xpNeeded = xpNeeded;
        this.xpEarned = 0;
        this.rewards = new Equipment[0];
    }
    
    public Level(int xpNeeded, Equipment[] rewards) {
        this.xpNeeded = xpNeeded;
        this.xpEarned = 0;
        this.rewards = rewards != null ? rewards : new Equipment[0];
    }
    
    //methods
    
    /**
     * Level up - unlocks all equipment rewards and returns them
     * @return Array of Equipment rewards (now unlocked)
     */
    public Equipment[] levelUp() {
        System.out.println("LEVEL UP! ");
        
        //unlocking rewards using unlockEquipment()
        for (Equipment equipment : rewards) {
            equipment.unlockEquipment();
        }
        if (rewards.length > 0) {
            System.out.println("Equipment Unlocked: " + rewards.length + " pieces");
        } else {
            System.out.println("(No equipment rewards for this level)");
        }
        
        //resseting XP earned for next level
        this.xpEarned = 0;
        return this.rewards;
    }
    
    /**
     *show rewards without unlocking them (preview)
     *@return Array of Equipment rewards
     */
    public Equipment[] showReward() {
        return this.rewards;
    }
    
    /**
     *update the XP earned in this level
     * @param xp total XP
     */
    public void updateXp(int xp) {
        this.xpEarned = xp;
        
        double progress = getProgress();
        int remaining = getXpRemaining();
        
        System.out.println(String.format(
            "Level Progress: %d/%d XP (%.1f%%) - %d XP remaining",
            xpEarned, xpNeeded, progress, remaining
        ));
        
        if (isComplete()) {
            System.out.println("✨ Level requirement met! Ready to level up!");
            if (rewards.length > 0) {
                System.out.println("Rewards available: " + rewards.length + " equipment pieces");
            }
        }
    }
    
    //helper methods
    
    public boolean isComplete() {
        return xpEarned >= xpNeeded;
    }
    
    public double getProgress() {
        if (xpNeeded <= 0) return 100.0;
        return Math.min(((double) xpEarned / xpNeeded) * 100.0, 100.0);
    }
    
    public int getXpRemaining() {
        return Math.max(0, xpNeeded - xpEarned);
    }
    
    public void addReward(Equipment equipment) {
        if (equipment == null) return;
        Equipment[] newRewards = new Equipment[rewards.length + 1];
        System.arraycopy(rewards, 0, newRewards, 0, rewards.length);
        newRewards[rewards.length] = equipment;
        this.rewards = newRewards;
    }
    
    public int getRewardCount() {
        return rewards.length;
    }
    
    public int getTotalRewardValue() {
        int total = 0;
        for (Equipment eq : rewards) {
            total += eq.getCost();
        }
        return total;
    }
    
    // GETTERS AND SETTERS
    
    public int getXpNeeded() { return xpNeeded; }
    public void setXpNeeded(int xpNeeded) { this.xpNeeded = xpNeeded; }
    
    public int getXpEarned() { return xpEarned; }
    public void setXpEarned(int xpEarned) { this.xpEarned = xpEarned; }
    
    public Equipment[] getRewards() { return rewards; }
    public void setRewards(Equipment[] rewards) { this.rewards = rewards; }
    
    public int getLvl() { return lvl; }
    public void setLvl(int lvl) { this.lvl = lvl; }
    
    @Override
    public String toString() {
        return String.format("Level[xpNeeded=%d, xpEarned=%d, progress=%.1f%%, rewards=%d]",
            xpNeeded, xpEarned, getProgress(), rewards.length);
    }
    
    // TESTING
    public static void main(String[] args) {
        System.out.println("Testing Level Class\n");
        
        // Create equipment rewards
        Equipment sword = new Equipment("Bronze Sword", 100, EquipmentType.WEAPON);
        Equipment boots = new Equipment("Leather Boots", 75, EquipmentType.FOOTWEAR);
        Equipment helmet = new Equipment("Iron Helmet", 150, EquipmentType.HELMET);
        
        // Create level with rewards
        Level level2 = new Level(1000, new Equipment[]{sword, boots, helmet});
        System.out.println("Created: " + level2);
        System.out.println("Total reward value: $" + level2.getTotalRewardValue());
        System.out.println();
        System.out.println("Preview Rewards");
        Equipment[] preview = level2.showReward();
        for (Equipment eq : preview) {
            System.out.println("  " + eq.toString());
        }
        System.out.println();
        
        //XP earned
        System.out.println("Earning XP");
        level2.updateXp(250);
        level2.updateXp(500);
        level2.updateXp(750);
        level2.updateXp(1000);
        System.out.println();
        
        //level up
        System.out.println("Level Up");
        Equipment[] earned = level2.levelUp();
        System.out.println("\nEarned " + earned.length + " equipment pieces:");
        for (Equipment eq : earned) {
            System.out.println("  " + eq.toString());
        }
    }
}

