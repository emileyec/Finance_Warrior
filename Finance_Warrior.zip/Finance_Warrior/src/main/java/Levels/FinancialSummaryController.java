/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Levels;
import Application.FWApp;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Jemima Gay
 */
public abstract class FinancialSummaryController implements ActionListener{
    private FWApp app;
    private FinancialSummaryView view;
    
    /**
     * Constructor
     * 
     * @param app Reference to FWApp
     * @param view Reference to FinancialSummaryView
     */
    public FinancialSummaryController(FWApp app, FinancialSummaryView view) {
        this.app = app;
        this.view = view;
    }
    
    //methods
    
    /**
     * Handle action events from the view
     * Required by ActionListener interface
     * 
     * @param e The ActionEvent
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        
        if (command.equals("VIEW_SUMMARY")) {
            String timeframe = view.getSelectedTimeframe();
            requestSummary(timeframe);
        }
    }
    
    /**
     * Request a summary for a specific timeframe
     * 
     * @param timeframe The timeframe
     */
    public void requestSummary(String timeframe) {
        try {
            //getting the summary from FWApp
            // String summary = app.generateFinancialSummary(timeframe);
            // view.updateSummary(summary);
            System.out.println("Summary generated for timeframe: " + timeframe);
        } catch (Exception ex) {
            view.showError("Error generating summary: " + ex.getMessage());
        }
    }
    
    /**
     * helpers
     * initializing view with current data
     */
    public void initializeView() {
        requestSummary("All Time");
    }
    
    //summary refresh
    public void refreshSummary() {
        String currentTimeframe = view.getSelectedTimeframe();
        requestSummary(currentTimeframe);
    }
    //getters
    public FWApp getApp() {
        return app;
    }
    
    public FinancialSummaryView getView() {
        return view;
    }
}
