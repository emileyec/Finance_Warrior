/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Levels;

/**
 *
 * @author Jemima Gay
 */
public class Vault {
    //attributes
    private int Coins;                      //current coins available
    private int totalSaved;                 //total amount saved over time
    private int questsCompleted;            //number of quests completed
    private int achievementsUnlocked;       //number of achievements unlocked
    
    /**
     *initializing empty vault (constructor)
     */
    public Vault() {
        this.Coins = 0;
        this.totalSaved = 0;
        this.questsCompleted = 0;
        this.achievementsUnlocked = 0;
    }
    
    /**
     * Constructor with initial values
     * @param coins
     * @param totalSaved
     * @param questsCompleted
     * @param achievementsUnlocked
     */
    public Vault(int coins, int totalSaved, int questsCompleted, int achievementsUnlocked) {
        this.Coins = coins;
        this.totalSaved = totalSaved;
        this.questsCompleted = questsCompleted;
        this.achievementsUnlocked = achievementsUnlocked;
    }
    
    //methods
    
    /**
     * Load data from a source
     */
    public void loadData() {
        // TODO: Implement loading from database
        System.out.println("Loading vault data...");
    }
    
    /**
     * Update savings amount
     * 
     * @param amount Amount to add to savings
     */
    public void updateSavings(int amount) {
        if (amount > 0) {
            this.Coins += amount;
            this.totalSaved += amount;
            System.out.println("Vault updated: Added $" + amount);
            System.out.println("Current coins: $" + Coins);
            System.out.println("Total saved: $" + totalSaved);
        } else {
            System.err.println("Cannot update savings with negative amount");
        }
    }
    
    /**
     * Update the number of coins
     * 
     * @param coins New coin amount
     */
    public void updateCoins(int coins) {
        this.Coins += coins;
        System.out.println("Coins updated to: $" + Coins);
    }
    
    /**
     *generating a report of vault status
     * 
     * @param timeframe Timeframe for the report (e.g., "weekly", "monthly")
     * @return Report as a String
     */
    public String generateReport(String timeframe) {
        StringBuilder report = new StringBuilder();
        report.append("========================================\n");
        report.append("      VAULT REPORT - ").append(timeframe.toUpperCase()).append("\n");
        report.append("========================================\n");
        report.append("Current Coins:            $").append(String.format("%,d", Coins)).append("\n");
        report.append("Total Saved:              $").append(String.format("%,d", totalSaved)).append("\n");
        report.append("Quests Completed:         ").append(questsCompleted).append("\n");
        report.append("Achievements Unlocked:    ").append(achievementsUnlocked).append("\n");
        report.append("========================================\n");
        
        return report.toString();
    }
    
    //helper methods
    
    /**
     *spend coins (reduces Coins but not totalSaved)
     * 
     * @param amount Amount to spend
     * @return True if successful, false if insufficient coins
     */
    public boolean spendCoins(int amount) {
        if (amount <= 0) {
            System.err.println("Cannot spend negative or zero amount");
            return false;
        }
        
        if (amount > Coins) {
            System.err.println("Insufficient coins. Available: $" + Coins + ", Needed: $" + amount);
            return false;
        }
        
        this.Coins -= amount;
        System.out.println("Spent $" + amount + ". Remaining: $" + Coins);
        return true;
    }
    
    /**
     *complete a quest
     * increments quests completed counter
     */
    public void completeQuest() {
        this.questsCompleted++;
        System.out.println("Quest completed! Total quests: " + questsCompleted);
    }
    
    /**
     *unlock an achievement
     *increments achievements unlocked counter
     */
    public void unlockAchievement() {
        this.achievementsUnlocked++;
        System.out.println("Achievement unlocked! Total achievements: " + achievementsUnlocked);
    }
    
    /**
     *geting ratio of saved to earned
     * 
     * @return Savings rate as percentage
     */
    public double getSavingsRate() {
        if (totalSaved <= 0) {
            return 0.0;
        }
        return ((double) Coins / totalSaved) * 100.0;
    }
    
    //getters and setters
    
    public int getCoins() {
        return Coins;
    }
    
    public void setCoins(int coins) {
        this.Coins = coins;
    }
    
    public int getTotalSaved() {
        return totalSaved;
    }
    
    public void setTotalSaved(int totalSaved) {
        this.totalSaved = totalSaved;
    }
    
    public int getQuestsCompleted() {
        return questsCompleted;
    }
    
    public void setQuestsCompleted(int questsCompleted) {
        this.questsCompleted = questsCompleted;
    }
    
    public int getAchievementsUnlocked() {
        return achievementsUnlocked;
    }
    
    public void setAchievementsUnlocked(int achievementsUnlocked) {
        this.achievementsUnlocked = achievementsUnlocked;
    }
    
    //utility methods
    
    @Override
    public String toString() {
        return String.format("Vault[coins=$%,d, totalSaved=$%,d, quests=%d, achievements=%d]",
            Coins, totalSaved, questsCompleted, achievementsUnlocked);
    }
    
    /**
     *get summary of vault status
     * 
     * @return Summary string
     */
    public String getSummary() {
        return String.format(
            "Coins: $%,d | Total Saved: $%,d | Quests: %d | Achievements: %d",
            Coins, totalSaved, questsCompleted, achievementsUnlocked
        );
    }
    
    //tester
    
    public static void main(String[] args) {
        System.out.println("Testing Vault Class\n");
        Vault vault = new Vault();
        System.out.println("New vault: " + vault);
        //add savings
        vault.updateSavings(1000);
        vault.updateSavings(500);
        //complete quests
        vault.completeQuest();
        vault.completeQuest();
        vault.completeQuest();
        //unlock achievements
        vault.unlockAchievement();
        vault.unlockAchievement();
        vault.spendCoins(300);
        System.out.println("\n" + vault.generateReport("Weekly"));
        System.out.println(vault.getSummary());
        Vault vault2 = new Vault(5000, 10000, 15, 8);
        System.out.println("\nVault with initial values: " + vault2);
        System.out.println(vault2.generateReport("Monthly"));
    }
}
