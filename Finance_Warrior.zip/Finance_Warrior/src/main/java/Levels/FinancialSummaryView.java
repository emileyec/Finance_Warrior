/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Levels;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author Jemima Gay
 */
public class FinancialSummaryView extends JFrame {
     //attributes
    private JComboBox<String> timeframeBox;    // Dropdown for selecting timeframe
    private JButton viewSummaryButton;          // Button to view summary
    private JTextArea summaryDisplay;           // Text area to display summary
    //controller reference
    private FinancialSummaryController controller;
    
    /**
     * Constructor
     */
    public FinancialSummaryView() {
        initializeComponents();
        layoutComponents();
        setupWindow();
    }
    
    /**
     * initializing all UI components
     */
    private void initializeComponents() {
        //timeframe selection
        String[] timeframes = {"Daily", "Weekly", "Monthly", "Yearly", "All Time"};
        timeframeBox = new JComboBox<>(timeframes);
        timeframeBox.setPreferredSize(new Dimension(150, 30));
        
        //view summary button
        viewSummaryButton = new JButton("View Summary");
        viewSummaryButton.setPreferredSize(new Dimension(150, 30));
        styleButton(viewSummaryButton);
        
        //summary display text area
        summaryDisplay = new JTextArea(20, 50);
        summaryDisplay.setEditable(false);
        summaryDisplay.setFont(new Font("Monospaced", Font.PLAIN, 12));
        summaryDisplay.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        summaryDisplay.setBackground(new Color(245, 245, 245));
    }
    
    /**
     * Layout components in the frame
     */
    private void layoutComponents() {
        setLayout(new BorderLayout(10, 10));
        
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        controlPanel.setBackground(new Color(102, 126, 234));
        controlPanel.setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));
        
        JLabel timeframeLabel = new JLabel("Select Timeframe:");
        timeframeLabel.setForeground(Color.WHITE);
        timeframeLabel.setFont(new Font("Arial", Font.BOLD, 14));
        
        controlPanel.add(timeframeLabel);
        controlPanel.add(timeframeBox);
        controlPanel.add(viewSummaryButton);
        
        add(controlPanel, BorderLayout.NORTH);
        
        //center panels
        JPanel displayPanel = new JPanel(new BorderLayout(10, 10));
        displayPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel titleLabel = new JLabel("Financial Summary", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        displayPanel.add(titleLabel, BorderLayout.NORTH);
        
        JScrollPane scrollPane = new JScrollPane(summaryDisplay);
        displayPanel.add(scrollPane, BorderLayout.CENTER);
        
        add(displayPanel, BorderLayout.CENTER);
    }
    
    /**
     *window properties
     */
    private void setupWindow() {
        setTitle("Financial Warrior - Financial Summary");
        setSize(700, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    
    /**
     *button style
     */
    private void styleButton(JButton button) {
        button.setBackground(new Color(34, 139, 34));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.BOLD, 14));
    }
    
    //methods
    
    /**
     *getting the selected timeframe from the combo box
     * 
     * @return Selected timeframe as String
     */
    public String getSelectedTimeframe() {
        return (String) timeframeBox.getSelectedItem();
    }
    
    /**
     *adding a view summary listener (action listener for the button)
     * 
     * @param listener The ActionListener to add
     */
    public void addViewSummaryListener(java.awt.event.ActionListener listener) {
        viewSummaryButton.addActionListener(listener);
    }
    
    /**
     *updating the summary display with new text
     * 
     * @param summary The summary text to display
     */
    public void updateSummary(String summary) {
        summaryDisplay.setText(summary);
        summaryDisplay.setCaretPosition(0); // Scroll to top
    }
    
    //controller
    
    /**
     *setting the controller for this view
     * 
     * @param controller The FinancialSummaryController
     */
    public void setController(FinancialSummaryController controller) {
        this.controller = controller;
        viewSummaryButton.addActionListener(controller);
        viewSummaryButton.setActionCommand("VIEW_SUMMARY");
    }
    
    //utility methods 
    
    /**
     * Show error message dialog
     * 
     * @param message Error message
     */
    public void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    /**
     * Show info message dialog
     * 
     * @param message Info message
     */
    public void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Information", JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Clear the summary display
     */
    public void clearSummary() {
        summaryDisplay.setText("");
    }
    
    /**
     * Append text to the summary display
     * 
     * @param text Text to append
     */
    public void appendToSummary(String text) {
        summaryDisplay.append(text);
    }
    
    //getters for controller access
    
    public JComboBox<String> getTimeframeBox() {
        return timeframeBox;
    }
    
    public JButton getViewSummaryButton() {
        return viewSummaryButton;
    }
    
    public JTextArea getSummaryDisplay() {
        return summaryDisplay;
    }
    
    //tester
    
    /**
     * Main method for testing the view
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            FinancialSummaryView view = new FinancialSummaryView();
            
            // Add a simple listener for testing
            view.addViewSummaryListener(e -> {
                String timeframe = view.getSelectedTimeframe();
                String testSummary = "========================================\n" +
                                    "   FINANCIAL SUMMARY - " + timeframe.toUpperCase() + "\n" +
                                    "========================================\n" +
                                    "Total Savings:         $5,000\n" +
                                    "Total Expenses:        $2,000\n" +
                                    "Net Worth:             $3,000\n" +
                                    "Quests Completed:      15\n" +
                                    "Achievements Unlocked: 8\n" +
                                    "========================================\n";
                
                view.updateSummary(testSummary);
            });
            
            view.setVisible(true);
        });
    }
}
