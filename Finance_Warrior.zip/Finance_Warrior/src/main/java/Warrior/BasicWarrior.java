/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Warrior;

/**
 *
 * @author Nishat Shaneen
 */
import java.util.ArrayList;
import java.util.List;
import Armory.Armory;
import Events.*;
import Levels.*;

// Decorator Pattern
public class BasicWarrior implements Warrior {
    private String username;
    private int level;
    private List<Quest> activeQuests;
    private Armory armory;

    /**
     * 
     * @param username name of user
     * @param armory user's collection of equipment
     * @param lvl current user level
     */
    public BasicWarrior(String username, Armory armory, Level lvl) {
    this.username = username;
    if (lvl.getLvl() > 0) {
        this.level = lvl.getLvl(); // allow any positive level
    } else {
        this.level = 1;
    }
    this.armory = armory;
    this.activeQuests = new ArrayList<>();
    }


    /**
     * Shows ALL equipment in the armory
     */
    @Override
    public void browseEquipment() {
        System.out.println("Showing all equipment for warrior: " + username);
    }

    /**
     * 
     * @param xp to the basic warrior
     */
    @Override
    public void addXP(int xp) {
        this.level += xp;
        System.out.println(username + " gained " + xp + " XP. Level is now: " + level);
    }

    //  Getters and Setters
    public Warrior getWarrior() {
        return this;
    }
    
    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public int getLevel() {
        return level;
    }
    
    @Override
    public Armory getArmory() {
        return armory;
    }
}
