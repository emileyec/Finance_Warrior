/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Warrior;

/**
 *
 * @author Nishat Shaneen
 */
// DECORATOR PATTERN
public abstract class WarriorDecorator implements Warrior {
    protected Warrior decoratedWarrior;

    /**
     * 
     * @param warrior - the object being decorated
     */
    public WarriorDecorator(Warrior warrior) {
        this.decoratedWarrior = warrior;
    }

    /**
     * shows ALL equipment in the armmory
     */
    @Override
    public void browseEquipment() {
        decoratedWarrior.browseEquipment();
    }

    /**
     * 
     * @param xp - adds to the decorated warrior
     */
    @Override
    public void addXP(int xp) {
        decoratedWarrior.addXP(xp);
    }
    
    // Getters and Setters
    public Warrior getWarrior() {
        return decoratedWarrior;
    }
    
    @Override
    public String getUsername() {
        return decoratedWarrior.getUsername();
    }

    @Override
    public int getLevel() {
        return decoratedWarrior.getLevel();
    }
}
