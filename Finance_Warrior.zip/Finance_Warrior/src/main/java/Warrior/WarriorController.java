/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Warrior;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Application.*;
import Armory.*;
import java.util.ArrayList;

public class WarriorController implements ActionListener {

    private WarriorView warriorView;
    private Warrior warrior;
    private FWApp homeScreen;   // this is the CardLayout controller
    private Armory armory;

    public WarriorController(WarriorView warriorView, Warrior warrior, FWApp homeScreen, Armory armory) {
        this.warriorView = warriorView;
        this.warrior = warrior;
        this.homeScreen = homeScreen;
        this.armory = armory;
    }

    public void setWarriorView(WarriorView view) {
        this.warriorView = view;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();

        switch (command) {

            case "browse":
                openArmory(false);   // show all equipment
                break;

            case "customize":
                openArmory(true);    // unlocked-only
                break;

            case "back":
                homeScreen.showMain();  // go back to main menu
                break;
        }
    }

    /** Open armory panel through FWApp’s CardLayout **/
    private void openArmory(boolean unlockedOnly) {
        armory.setSortStrategy(
                unlockedOnly ? new SortByUnlocked() : new SortByType()
        );

        // Create ArmoryView as a JPanel
        ArmoryView armoryView = new ArmoryView(homeScreen, warriorView);

        // Create controller
        ArmoryController armoryController = new ArmoryController(armory, armoryView);

        // Fill list
        EquipmentIterator iterator = armory.createIterator();
        ArrayList<Equipment> list = new ArrayList<>();
        while (iterator.hasNext()) {
            list.add(iterator.next());
        }

        armoryView.updateEquipmentList(list);

        homeScreen.showPanel(armoryView);
    }
}
