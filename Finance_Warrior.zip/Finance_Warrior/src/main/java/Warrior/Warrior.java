/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Warrior;

import Armory.Armory;

/**
 *
 * @author Nishat Shaneen
 */
public interface Warrior {
    void browseEquipment(); // show all equipment in the armory
    void addXP(int xp); // add experience points in order to level up
    // Getters and Setters
    String getUsername();
    int getLevel();
    Armory getArmory();
}
