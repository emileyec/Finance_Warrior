/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Warrior;

/**
 *
 * @author Nishat Shaneen
*/

import Armory.*;
import Events.*;

public class ArmoredWarrior extends WarriorDecorator {
    private QuestList activeQuests;
    private String background;
    private Armory armory; // warrior's personal armory
    
    /**
     * Constructor
     * @param warrior interface
     * @param armory collection of equipment
     * @param quests list of warrior's quests
     */
    public ArmoredWarrior(Warrior warrior, Armory armory, QuestList quests) {
        super(warrior);
        this.armory = armory;
        this.activeQuests = quests;
    }

    // Show all equipment (for Browse button)
    @Override
    public void browseEquipment() {
        System.out.println("All equipment:");
        EquipmentIterator iterator = armory.createIterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next().getName());
        }
        super.browseEquipment();
    }

    // Show only unlocked equipment (for Customize button)
    public void customize() {
        if (getLevel() < 5) {
            System.out.println("Customize not available: Warrior must be level 5 or higher.");
            return;
        }

        System.out.println("Unlocked equipment for customization:");
        armory.setSortStrategy(new SortByUnlocked());
        EquipmentIterator iterator = armory.createIterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next().getName());
        }
    }

    /**
     * 
     * @param xp to decorated warrior
     */
    @Override
    public void addXP(int xp) {
        super.addXP(xp);
    }

    // Getters and Setters
    // username and level to decorated warrior
    @Override
    public String getUsername() {
        return decoratedWarrior.getUsername();
    }

    @Override
    public int getLevel() {
        return decoratedWarrior.getLevel();
    }

    public QuestList getActiveQuests() {
        return activeQuests;
    }

    public void setBackground(String bg) {
        this.background = bg;
    }

    @Override
    public Armory getArmory() {
        return armory;
    }
}
