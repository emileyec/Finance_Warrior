/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Warrior;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.net.URL;

public class WarriorView extends JPanel {
    private JLabel warriorTypeLabel, warriorNameLabel, levelLabel, warriorImageLabel;
    private JButton browseButton, customizeButton, backButton;
    private Warrior warrior;

    /**
     * MVC
     * @param warrior MODEL
     * @param controller CONTROLLER
     */
    public WarriorView(Warrior warrior, ActionListener controller) {
        this.warrior = warrior;

        setLayout(new BorderLayout());

        String typeName = (warrior instanceof ArmoredWarrior)
                ? "Armored Warrior"
                : "Basic Warrior";

        warriorTypeLabel = new JLabel(typeName, SwingConstants.CENTER);
        warriorNameLabel = new JLabel("Name: " + warrior.getUsername());
        levelLabel = new JLabel("Level: " + warrior.getLevel());

        // IMAGE
        if (warrior instanceof ArmoredWarrior) {
            URL u = getClass().getResource("/armoredWarrior.gif");
            if (u != null) {
                ImageIcon img = new ImageIcon(u);
                Image scaled = img.getImage().getScaledInstance(120, 120, Image.SCALE_SMOOTH);
                warriorImageLabel = new JLabel(new ImageIcon(scaled));
            } else {
                warriorImageLabel = new JLabel("No Sprite Found");
            }
        } else {
            warriorImageLabel = new JLabel("No Sprite");
        }

        // BUTTONS
        browseButton = new JButton("Browse All Equipment");
        browseButton.setActionCommand("browse");
        browseButton.addActionListener(controller);

        customizeButton = new JButton("Customize (Unlocked Only)");
        customizeButton.setActionCommand("customize");
        customizeButton.addActionListener(controller);

        backButton = new JButton("Back");
        backButton.setActionCommand("back");
        backButton.addActionListener(controller);

        boolean canCustomize = warrior instanceof ArmoredWarrior && warrior.getLevel() >= 5;
        customizeButton.setVisible(canCustomize);
        customizeButton.setEnabled(canCustomize);

        // MAIN PANEL
        JPanel infoPanel = new JPanel(new GridLayout(0, 1, 10, 10));
        infoPanel.add(warriorTypeLabel);
        infoPanel.add(warriorNameLabel);
        infoPanel.add(levelLabel);
        infoPanel.add(warriorImageLabel);
        infoPanel.add(browseButton);
        infoPanel.add(customizeButton);
        infoPanel.add(backButton);

        add(infoPanel, BorderLayout.CENTER);

        setPreferredSize(new Dimension(400, 400));
    }
}
