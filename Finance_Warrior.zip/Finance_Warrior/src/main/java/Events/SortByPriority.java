/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Events;
import java.util.ArrayList;
import java.util.Comparator;
/**
 * Sort strategy that orders the quests by priority level in ascending order
 *
 * @author emile
 */
public class SortByPriority implements QuestSorter{
    /**
     * sorts the quests by priority level
     * @param quests - list of quests to be sorted
     */
    @Override
    public void sort(ArrayList<Quest> quests){
        quests.sort(Comparator.comparingInt(Quest::getPriorityLvl));
    }
}
