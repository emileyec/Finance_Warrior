/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Events;
import java.util.ArrayList;
import java.util.Comparator;
/**
 * sort strategy that sorts the quests by due date
 *
 * @author emiley
 */
public class SortByDue implements QuestSorter{
    /**
     * sorts the list of quests by due date
     * @param quests - list of quests to be sorted
     */
    @Override
    public void sort(ArrayList<Quest> quests){
        quests.sort(Comparator.comparing(Quest::getDueDate));
    }
}

