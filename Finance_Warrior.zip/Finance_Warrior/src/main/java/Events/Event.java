/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

package Events;

/**
 * Represents an event in the Finance Warrior Application
 * Quest, Achievement, and MiniEvent implement this interface and provide their 
 *  own logic for each method
 *
 * @author emiley
 */
public interface Event {
    void addXP();
    void addCoins();
    void complete();
    String getType();
    String viewDetails();
}



