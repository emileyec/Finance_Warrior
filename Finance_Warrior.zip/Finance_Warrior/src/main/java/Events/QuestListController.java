/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Events;
import java.util.Date;
import java.util.ArrayList;
import Levels.*;

/**
 * Plays the controller part in the MVC structure, receiving input and making changes to the model to be displayed in the view
 *
 * @author emiley
 */
public class QuestListController {
    private final QuestList questList;
    private final QuestListView view;
    private final Level level;
    private final Vault vault;


    /**
     * constructor for a QuestListController object that will manage a QuestList and update a QuestListView
     * @param questList - the quest list model
     * @param view - the quest list view that will be updated
     */
    public QuestListController(QuestList questList, QuestListView view, Level level, Vault vault) {
        this.questList = questList;
        this.view = view;
        this.level = level;
        this.vault = vault;

    }

    /**
     * Creates a new Quest to be added to the QuestList, then refreshes the view
     * 
     * @param id - quest's identifier
     * @param goal - goal to be completed
     * @param creation - creation date of the quest
     * @param due - due date of the quest
     * @param priority - quest's priority level
     */
    public void addQuest(String id, String goal, Date creation, Date due, int priority) {
        QuestCreator creator = new QuestCreator(id, goal, creation, due, priority, level, vault);
        Quest newQuest = (Quest) creator.createEvent();
        questList.addQuest(newQuest);
        view.refresh(getQuests());
    }

    /**
     * updates and existing quest by modifying it's attributes, then refreshes the view
     * @param quest - quest to be updated
     * @param newGoal - new goal 
     * @param newDue - new due date
     * @param newPriority - new priority level
     * @param newStatus - new status
     */
    public void updateQuest(Quest quest, String newGoal, Date newDue, int newPriority, String newStatus) {
        quest.setGoal(newGoal);
        quest.setDueDate(newDue);
        quest.setPriorityLvl(newPriority);
        quest.setStatus(newStatus);
        view.refresh(getQuests());
    }

    /**
     * removes a quest from the list and refreshes the view
     * @param quest - quest to be removed
     */
    public void removeQuest(Quest quest) {
        questList.removeQuest(quest);
        view.refresh(getQuests());
    }
    
    /**
     * sorts the quest list by priority level then refreshes the view
     */
    public void sortByPriority() {
        questList.setSortStrategy(new SortByPriority());
        view.refresh(getQuests());
    }

    /**
     * sorts the list  by due date then refreshes the view
     */
    public void sortByDueDate() {
        questList.setSortStrategy(new SortByDue());
        view.refresh(getQuests());
    }

    /**
     * gets the list of quests sorted correctly
     * @return - list of quests
     */
    public ArrayList<Quest> getQuests() {
        return questList.getAll();
    }
}
