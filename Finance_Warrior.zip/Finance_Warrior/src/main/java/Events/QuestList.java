/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Events;
import java.util.ArrayList;
/**
 * Holds and manages a list of Quest objects and applies a sort strategy to the list
 * 
 * Plays the model part in the MVC structure
 *
 * @author emiley
 */
public class QuestList {
    private ArrayList<Quest> questList;
    private QuestSorter sortStrategy;
    
    /**
     * Constructor method to create a QuestList object
     */
    public QuestList(){
        this.questList = new ArrayList<Quest>();
        this.sortStrategy = null;
    }
    
    /**
     * Method that returns all of the quests in a sorted order based on the stored sortStrategy
     * @return - a sorted copy of the ArrayList of Quests
     */
    public ArrayList<Quest> getAll(){
        if (sortStrategy != null) {
            // Return a sorted copy so the original list is not modified
            ArrayList<Quest> sorted = new ArrayList<>(questList);
            sortStrategy.sort(sorted);
            return sorted;
        }
        return questList;
    }
    
    /**
     * sets the sorting strategy for when quests are retrieved
     * @param s - an object of one of the classes that implement the QuestSorter interface
     */
    public void setSortStrategy(QuestSorter s){
        this.sortStrategy = s;
    }
    
    /**
     * method to add a quest to the list
     * @param q - a new quest to be added
     */
    public void addQuest(Quest q){
        if (q != null){
            questList.add(q);
        }
    }
    
    /**
     * method to remove a quest from the list
     * @param q - quest that should be removed
     */
    public void removeQuest(Quest q) {
        questList.remove(q);
    }

    /**
     * replaces an existing quest in the list with a new one
     * @param oldQuest - quest to be replaced
     * @param newQuest - new quest to insert
     */
    public void updateQuest(Quest oldQuest, Quest newQuest) {
        int index = questList.indexOf(oldQuest);
        if (index != -1) {
            questList.set(index, newQuest);
        }
    }
}


