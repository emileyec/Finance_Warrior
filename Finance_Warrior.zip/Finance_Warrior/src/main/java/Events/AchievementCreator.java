/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Events;
import java.util.Date;
import Levels.*;

/**
 * Factory class that extends the EventCreator class
 * This class creates Achievement objects
 *
 * @author emiley
 */
public class AchievementCreator extends EventCreator{
    private String achievementId;
    private String title;
    private String details;
    private int xp;
    private int coins;
    private Level level;
    private Vault vault;


    /**
     * Constructor for AchievementCreator objects
     * 
     * @param achievementId - identifier for the achievement
     * @param title - title of the achievement
     * @param details - details of the achievement
     * @param xp - xp rewarded for completing the achievement
     * @param coins - coins rewarded for completing the achievement
     * @param level - level to add xp to
     * @param vault - vault to add coins to
     */
    public AchievementCreator(String achievementId, String title, String details, int xp, int coins, Level level, Vault vault) {
        this.achievementId = achievementId;
        this.title = title;
        this.details = details;
        this.xp = xp;
        this.coins = coins;
        this.level = level;
        this.vault = vault;
    }
    
    /**
     * Creates a new Achievement object
     * 
     * @return - new Achievement object
     */
    @Override
    public Event createEvent(){
        return new Achievement(achievementId, title, details, xp, coins, level, vault);
    }
}
