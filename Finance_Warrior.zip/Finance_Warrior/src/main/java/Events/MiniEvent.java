/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Events;
import java.util.Date;
import Levels.*;
/**
 * Represents a limited-time event that the user can gain xp and coins from
 *
 * @author emiley
 */
public class MiniEvent implements Event{
    private String eventId;
    private String title;
    private String quote;
    private int xp;
    private int coins;
    private Date expiration;
    private boolean isActive;
    private Level level;
    private Vault vault;

    
    /**
     * Constructor for a new MiniEvent object 
     * 
     * @param eventId - event identifier
     * @param title - name of the event
     * @param quote - quote displayed when event occurs
     * @param xp - xp rewarded for completion
     * @param coins - coins rewarded for completion
     * @param expiration - event expiration date
     * @param level - level to add xp to
     * @param vault - vault to add coins to
     */
    public MiniEvent(String eventId, String title, String quote, int xp, int coins, Date expiration, Level level, Vault vault){
        this.eventId = eventId;
        this.title = title;
        this.quote = quote;
        this.xp = xp;
        this.coins = coins;
        this.expiration = expiration;
        this.isActive = true;
        this.level = level;
        this.vault = vault;
    }
    
    /**
     * Adds xp to the user
     */
    @Override
    public void addXP(){
        level.updateXp(xp);
    }
    
    /**
     * Adds coins to the user
     */
    @Override
    public  void addCoins(){
        vault.updateCoins(coins);
    }
    
    /**
     * completes the event by rewarding xp and coins and deactivating the event
     */
    @Override
    public void complete(){
        addXP();
        addCoins();
        isActive = false;
    }
    
    /**
     * returns the type of event 
     * @return - type of event
     */
    @Override
    public String getType(){
        return "MiniEvent";
    }
    
    /**
     * returns a formatted string with the event details
     * @return - event details in string form
     */
    @Override
    public String viewDetails(){
        return "MiniEvent Details:\n" +
               "ID: " + eventId + "\n" +
               "Title: " + title + "\n" +
               "Quote: " + quote + "\n" +
               "Expiration: " + expiration + "\n" +
               "Active: " + (isActive ? "Yes" : "No") + "\n" +
               "XP Reward: " + xp + "\n" +
               "Coin Reward: " + coins;
    }
}
