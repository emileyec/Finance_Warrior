/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Events;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;

/**
 * Acts as the view in the MVC structure, uses Swing components to create a UI
 * 
 * The UI displays the quests in a grid format with buttons to add, remove, edit and sort the quests
 */
public class QuestListView extends JPanel {
    private QuestListController controller;
    private JPanel questGridPanel;
    private JButton addQuestButton;
    private JComboBox<String> sortDropdown;
    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * constructs a view
     */
    public QuestListView() {
        initUI();
    }

    /**
     * sets up the UI components
     */
    private void initUI() {
        setLayout(new BorderLayout());

        questGridPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        JScrollPane scroll = new JScrollPane(questGridPanel);
        scroll.setBorder(null);
        add(scroll, BorderLayout.CENTER);
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        addQuestButton = new JButton("Add Quest");
        addQuestButton.addActionListener((ActionEvent e) -> openAddQuestDialog());

        sortDropdown = new JComboBox<>(new String[] {
            "Sort by Priority",
            "Sort by Due Date"
        });

        sortDropdown.addActionListener(e -> {
            String choice = (String) sortDropdown.getSelectedItem();
            if ("Sort by Priority".equals(choice)) {
                controller.sortByPriority();
            } else if ("Sort by Due Date".equals(choice)) {
                controller.sortByDueDate();
            }
        });

        buttonPanel.add(addQuestButton);
        buttonPanel.add(sortDropdown);
        add(buttonPanel, BorderLayout.NORTH);
    }

    /**
     * refreshes the grid with the provided list
     * @param quests - the list of quests
     */
    public void refresh(ArrayList<Quest> quests) {
        questGridPanel.removeAll();

        if (quests.isEmpty()) {
            JLabel empty = new JLabel("No quests available — become a financial warrior by adding one!");
            empty.setFont(new Font("Arial", Font.ITALIC, 14));
            questGridPanel.add(empty);
        } else {
            for (Quest q : quests) {
                questGridPanel.add(createQuestBox(q));
            }
        }

        questGridPanel.revalidate();
        questGridPanel.repaint();
    }

    /**
     * creates a single quest box panel with details and action buttons
     * @param quest - the quest to be displayed
     * @return - a formatted box to represent the quest
     */
    private JPanel createQuestBox(Quest quest) {
        JPanel box = new JPanel();
        box.setLayout(new BorderLayout());
        box.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.GRAY, 2),
                BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        box.setBackground(Color.WHITE);

        JLabel title = new JLabel(quest.getGoal());
        title.setFont(new Font("Arial", Font.BOLD, 16));

        JPanel details = new JPanel();
        details.setLayout(new BoxLayout(details, BoxLayout.Y_AXIS));
        details.setOpaque(false);

        JLabel id = new JLabel("ID: " + quest.getQuestId());
        JLabel due = new JLabel("Due: " + (quest.getDueDate() != null ? sdf.format(quest.getDueDate()) : "—"));
        JLabel priority = new JLabel("Priority: " + quest.getPriorityLvl());
        JLabel status = new JLabel("Status: " + quest.getStatus());

        id.setAlignmentX(Component.LEFT_ALIGNMENT);
        due.setAlignmentX(Component.LEFT_ALIGNMENT);
        priority.setAlignmentX(Component.LEFT_ALIGNMENT);
        status.setAlignmentX(Component.LEFT_ALIGNMENT);

        details.add(id);
        details.add(due);
        details.add(priority);
        details.add(status);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        actions.setOpaque(false);
        JButton editBtn = new JButton("Edit");
        JButton removeBtn = new JButton("Remove");

        editBtn.addActionListener(e -> openEditQuestDialog(quest));
        removeBtn.addActionListener(e -> controller.removeQuest(quest));

        actions.add(editBtn);
        actions.add(removeBtn);

        box.add(title, BorderLayout.NORTH);
        box.add(details, BorderLayout.CENTER);
        box.add(actions, BorderLayout.SOUTH);

        return box;
    }

    /**
     * Opens a dialog box that allows user input to create a new quest
     */
    private void openAddQuestDialog() {
        JTextField idField = new JTextField();
        JTextField goalField = new JTextField();
        JTextField priorityField = new JTextField();
        JTextField dueDateField = new JTextField("yyyy-MM-dd");

        JPanel panel = new JPanel(new GridLayout(0, 1, 4, 4));
        panel.add(new JLabel("Quest ID:"));
        panel.add(idField);
        panel.add(new JLabel("Goal:"));
        panel.add(goalField);
        panel.add(new JLabel("Priority (int):"));
        panel.add(priorityField);
        panel.add(new JLabel("Due Date (yyyy-MM-dd):"));
        panel.add(dueDateField);
        
        int result = JOptionPane.showConfirmDialog(this, panel, "Add New Quest", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String id = idField.getText().trim();
                String goal = goalField.getText().trim();
                int priority = Integer.parseInt(priorityField.getText().trim());
                Date due = java.sql.Date.valueOf(dueDateField.getText().trim());
                controller.addQuest(id, goal, new Date(), due, priority);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Priority must be an integer.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, "Due date must be in yyyy-MM-dd format.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid input!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    /**
     * opens a dialog box that takes user input to edit an existing quest
     * @param quest - the quest to be edited
     */
    private void openEditQuestDialog(Quest quest) {
        JTextField idField = new JTextField(quest.getQuestId());
        idField.setEditable(false);

        JTextField goalField = new JTextField(quest.getGoal());
        JTextField priorityField = new JTextField(String.valueOf(quest.getPriorityLvl()));
        JTextField dueDateField = new JTextField(quest.getDueDate() != null ? sdf.format(quest.getDueDate()) : "");

        String[] statuses = {"Not Started", "In Progress", "Completed"};
        JComboBox<String> statusDropdown = new JComboBox<>(statuses);
        statusDropdown.setSelectedItem(quest.getStatus());

        JPanel panel = new JPanel(new GridLayout(0, 1, 4, 4));
        panel.add(new JLabel("Quest ID:"));
        panel.add(idField);
        panel.add(new JLabel("Goal:"));
        panel.add(goalField);
        panel.add(new JLabel("Priority (int):"));
        panel.add(priorityField);
        panel.add(new JLabel("Due Date (yyyy-MM-dd):"));
        panel.add(dueDateField);
        panel.add(new JLabel("Status:"));
        panel.add(statusDropdown);


        int result = JOptionPane.showConfirmDialog(this, panel, "Edit Quest", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String newGoal = goalField.getText().trim();
                int newPriority = Integer.parseInt(priorityField.getText().trim());
                Date newDue = java.sql.Date.valueOf(dueDateField.getText().trim());
                String newStatus = (String) statusDropdown.getSelectedItem();

                controller.updateQuest(quest, newGoal, newDue, newPriority, newStatus);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Priority must be an integer.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, "Due date must be in yyyy-MM-dd format.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid input!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    /**
     * assigns a new controller for the view
     * @param controller - new controller to be assigned
     */
    public void setController(QuestListController controller) {
        this.controller = controller;
    }
}




