/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

package Events;
import java.util.ArrayList;
/**
 * Interface to be implemented by concrete strategy classes that will define a specific sort strategy
 *
 * @author emiley
 */
public interface QuestSorter {
    /**
     * sorts the provided list of quests based on the sort strategy
     * @param quest - list of quests to be sorted
     */
    void sort(ArrayList<Quest> quest);
}


