/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Events;
import java.util.Date;
import Levels.*;
/**
 * Factory class that creates MiniEvent objects
 *
 * @author emiley
 */
public class MiniEventCreator extends EventCreator{
    private String eventId;
    private String title;
    private String quote;
    private int xp;
    private int coins;
    private Date expiration;
    private Level level;
    private Vault vault;


    /**
     * constructor to create an instance if the MiniEventCreator class
     * 
     * @param eventId - event identifier
     * @param title - title of the event
     * @param quote - quote displayed during event
     * @param xp - xp rewarded for completion of event
     * @param coins - coins rewarded for completion of event
     * @param expiration - event expiration date
     * @param level - level to add xp to
     * @param vault - vault to add coins to
     */
    public MiniEventCreator(String eventId, String title, String quote, int xp, int coins, Date expiration, Level level, Vault vault) {
        this.eventId = eventId;
        this.title = title;
        this.quote = quote;
        this.xp = xp;
        this.coins = coins;
        this.expiration = expiration;
        this.level = level;
        this.vault = vault;
    }

    /**
     * creates a MiniEvent object
     * 
     * @return - a new MiniEvent object
     */
    @Override
    public Event createEvent(){
        return new MiniEvent(eventId, title, quote, xp, coins, expiration, level, vault);
    }
}

