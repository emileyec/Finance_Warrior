/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Events;
import java.util.Date;
import Levels.*;
/**
 * Factory class that creates Quest objects
 *
 * @author emiley
 */
public class QuestCreator extends EventCreator{
    private String questId;
    private String goal;
    private Date creation;
    private Date due;
    private int priorityLvl;
    private Level level;
    private Vault vault;


    /**
     * Constructor method to create an instance of the QuestCreator class
     * @param questId - quest identifier
     * @param goal - goal of the quest
     * @param creation - date the quest was created
     * @param due - date the quest should be completed by
     * @param priorityLvl - priority level of the quest
     * @param level - level to add xp to
     * @param vault - vault to add coins to
     */
    public QuestCreator(String questId, String goal, Date creation, Date due, int priorityLvl, Level level, Vault vault) {
        this.questId = questId;
        this.goal = goal;
        this.creation = creation;
        this.due = due;
        this.priorityLvl = priorityLvl;
        this.level = level;
        this.vault = vault;

    }

    /**
     * method to create Event objects, specifically Quests in this case
     * @return - a new Quest object
     */
    @Override
    public Event createEvent(){
        return new Quest(questId, goal, creation, due, priorityLvl, level, vault);
    }
}
