/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Events;

/**
 * Factory class for creating Event objects
 * Subclasses implement createEvent() method to create the specific Event they represent
 *
 * @author emiley
 */
public abstract class EventCreator {
    /**
     * Creates a new Event object type specific to the class that implements it
     * @return - new Event object
     */
    public abstract Event createEvent();
}
