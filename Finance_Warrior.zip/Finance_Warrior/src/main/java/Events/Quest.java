/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Events;
import java.util.Date;
import Levels.*;

/**
 * represents a goal that the user is working to accomplish
 *
 * @author emiley
 */
public class Quest implements Event{
    private final String questId;
    private String goal;
    private final Date creation;
    private Date due;
    private int priorityLvl;
    private String progress = "Not Started";
    private boolean isCompleted = false;
    private Level level;
    private Vault vault;

    
    /**
     * constructs a Quest object
     * 
     * @param questId - quest identifier
     * @param goal - goal to be completed
     * @param creation - quest creation date
     * @param due - quest due date
     * @param priorityLvl - priority level of the quest
     * @param level - level to add xp to
     * @param vault - vault to add coins to
     */
    public Quest(String questId, String goal, Date creation, Date due, int priorityLvl, Level level, Vault vault){
        this.questId = questId;
        this.goal = goal;
        this.creation = creation;
        this.due = due;
        this.priorityLvl = priorityLvl;
        this.level = level;
        this.vault = vault;
    }
    
    /**
     * awards xp when quest is completed
     */
    @Override
    public void addXP(){
        level.updateXp(10);
    }
    
    /**
     * awards coins when quest is completed
     */
    @Override
    public void addCoins(){
        vault.updateCoins(50);
    }
    
    /**
     * marks quest as complete
     * awards xp and coins and marks quest as complete
     */
    @Override
    public void complete(){
        isCompleted = true;
        progress = "Completed";
        addXP();
        addCoins();
    }
    
    /**
     * returns type of event
     * @return - string containing the type of event
     */
    @Override
    public String getType(){
        return "Quest";
    }    
    
    /**
     * reminds the user to complete the quest before the desires due date
     * @return - a formatted string reminder
     */
    public String remindWarrior(){
        return "Reminder: Your quest '" + goal + "' is due on " + due.toString();
    }
    
    /**
     * updates the progress of the quest
     * @param amount - the percentage of the quest completed
     */
    public void updateProgress(int amount){
        if (amount < 0) amount = 0;
        if (amount > 100) amount = 100;

        if (amount == 100) {
            complete();
        } else {
            progress = amount + "% completed";
        }
    }
    
    /**
     * getter method for progress
     * @return - progress of the quest
     */
    public String getStatus(){
        return progress;
    }
    
    /**
     * getter method for the goal
     * @return - the quest goal
     */
    public String getGoal(){
        return goal;
    }
    
    /**
     * getter method for the due date
     * @return - quest due date
     */
    public Date getDueDate(){
        return due;
    }
    
    /**
     * getter method for the priority level
     * @return - quest's priority level
     */
    public int getPriorityLvl(){
        return priorityLvl;
    }
    
    /**
     * getter method for the quest id
     * @return - quest's id
     */
    public String getQuestId(){
        return questId;
    }
    
    /**
     * setter method for the goal
     * @param goal - the new desired goal
     */
    public void setGoal(String goal){
        this.goal = goal;
    }
    
    /**
     * setter method for the due date
     * @param due - the new desired due date
     */
    public void setDueDate(Date due){
        this.due = due;
    }
    
    /**
     * setter method for the priority level
     * @param priorityLvl - the new desired priority level
     */
    public void setPriorityLvl(int priorityLvl){
        this.priorityLvl = priorityLvl;
    }
    
    /**
     * setter method for the status
     * @param status - the new desired status
     */
    public void setStatus(String status){
        this.progress = status;
    }
    
    /**
     * displays the details of the quest
     * @return - formatted string with all of the quest's details
     */
    @Override
    public String viewDetails(){
        return """
               Quest Details:
               ID: """ + questId + "\n"
            + "Goal: " + goal + "\n"
            + "Created: " + creation + "\n"
            + "Due: " + due + "\n"
            + "Priority: " + priorityLvl + "\n"
            + "Progress: " + progress + "\n"
            + "Completed: " + isCompleted;
    }
}


