/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Events;
import java.util.Date;
import Levels.*;
/**
 * Represents an achievement in the Finance Warrior Application
 * Implements the Event interface
 * 
 * @author emiley
 */
public class Achievement implements Event{
    private String achievementId;
    private String title;
    private String details;
    private int xp;
    private int coins;
    private Level level;
    private Vault vault;

    
    /**
     * Constructor for an Achievement
     * @param achievementId - identifier for the achievement
     * @param title - title of the achievement
     * @param details - details of the achievement
     * @param xp - xp rewarded for completing the achievement
     * @param coins - coins rewarded for completing the achievement
     * @param level - level to add xp to
     * @param vault - vault to add coins to
     */
    public Achievement(String achievementId, String title, String details, int xp, int coins, Level level, Vault vault){
        this.achievementId = achievementId;
        this.title = title;
        this.details = details;
        this.xp = xp;
        this.coins = coins;
        this.level = level;
        this.vault = vault;
    }
    
    /**
     * gives xp to the players vault when achievement is completed
     */
    @Override
    public void addXP(){
        level.updateXp(xp);
    }
    
    /**
     * gives coins to the players vault when achievement is completed
     */
    @Override
    public void addCoins(){
        vault.updateCoins(coins);
    }
    
    /**
     * completes the achievement by adding xp and coins
     */
    @Override
    public void complete(){
        addXP();
        addCoins();
    }
    
    /**
     * gets the type of Event
     * 
     * @return - the Event type
     */
    @Override
    public String getType(){
        return "Achievement";
    }

    /**
     * Returns a string with the formatted details of the event
     * @return - achievementId, title, details, xp, coins formatted in a string
     */
    @Override
    public String viewDetails(){
        return "Achievement Details:\n" +
           "ID: " + achievementId + "\n" +
           "Title: " + title + "\n" +
           "Description: " + details + "\n" +
           "XP Reward: " + xp + "\n" +
           "Coin Reward: " + coins;
    }
}



